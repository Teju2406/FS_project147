# Viva and Demonstration Guide

## 1. The whole project in simple words (say this first)

> "My project is a **Hospital Management System**. It is a web application where hospital staff can manage **patients, doctors and appointments**, and see a **dashboard** with total patients, doctors, appointments and free beds.
>
> I built the **frontend with React.js** – that is what the user sees in the browser. I built the **backend with Node.js and Express.js** – it is a server that exposes a **REST API**. For the **database** I used **JSON files**, because this is a college project and I wanted something simple and free.
>
> When the user clicks a button, React sends a request to the backend using `fetch()`. The backend checks the data, reads or writes the JSON file, and sends a response. React then updates the screen. Because the backend writes into the JSON files, the data stays saved even after refreshing the page or restarting the server."

### How frontend, backend and JSON work together (example: add a patient)

1. User fills the **Add Patient** form and clicks the button.
2. React checks the form (validation). If something is wrong it shows red messages and stops.
3. React calls `api.post("/patients", values)` → `fetch("http://localhost:5000/api/patients", { method: "POST", body: JSON })`.
4. Express receives it in `routes/patients.js`. `express.json()` turns the body into `req.body`.
5. The server validates again (never trust the browser), creates the next ID (`P013`), reads `patients.json`, pushes the new patient and writes the file back.
6. The server replies `201` + the new patient as JSON.
7. React closes the form, shows a success message and calls the API again to reload the list. The table now shows the new row.

**Short version:** *React (UI) → fetch → Express (logic) → JSON file (data) → response → React updates screen.*

---

## 2. Demonstration script (about 4 minutes)

**Before you start:** backend running in Terminal 1, frontend in Terminal 2, browser open at `http://localhost:5173`, browser zoom 100%. Have VS Code open with the folder structure visible.

| Time | What to do | What to say |
| ---- | ---------- | ----------- |
| 0:00 | Show the Dashboard | "This is the dashboard. The four cards show total patients, doctors, appointments and available beds. These numbers come from the backend API `/api/dashboard`. Below are recent appointments and simple statistics." |
| 0:30 | Click **Patients**. Type `aarav`, then `P003`. | "Here all patients are shown in a table. I can search by name or ID." |
| 0:50 | Click **Add Patient**, submit empty form | "The form is validated – required fields show errors, so invalid data is not sent." |
| 1:10 | Fill the form correctly, save | "Now I fill valid details. The new patient gets the next ID automatically and is saved into `patients.json`." (Optionally show the JSON file in VS Code.) |
| 1:40 | Edit that patient, then delete it (show confirmation) | "Edit reuses the same form, pre-filled. Delete asks for confirmation before removing the record." |
| 2:10 | Click **Doctors**, edit one doctor's availability | "Doctors are shown as cards with specialization, schedule and contact details. I can add, edit and delete them." |
| 2:40 | Click **Appointments**, filter by status | "Appointments show Scheduled, Completed or Cancelled status. I can filter by status." |
| 3:00 | **Book Appointment**: choose patient, a doctor, tomorrow's date, a time | "I choose patient, doctor, date and time." Save. |
| 3:20 | Try to book **the same doctor, date and time** again | "The system prevents double-booking and shows an error." |
| 3:35 | Mark one as **Completed**, **Cancel** another | "Staff can complete or cancel appointments." |
| 3:50 | Shrink the browser window (or phone mode with `F12`) | "The interface is responsive – the sidebar becomes a menu and tables become cards on a phone." |
| 4:10 | Open `http://localhost:5000/api/patients` | "This is the REST API the frontend talks to. The data really lives on the backend." |
| 4:20 | Refresh the page | "After refresh the data is still there because it is saved in JSON files, not only in React state." |

**If something goes wrong in the demo:** stay calm, click **Try again** (if the backend stopped, restart it with `npm start`), and explain what the error message means. Handling errors gracefully is a feature of the project.

---

## 3. Viva questions and easy answers

### A. HTML

**Q1. What is HTML and which version did you use?**
HTML (HyperText Markup Language) defines the structure of a web page. I used HTML5. In my project there is one HTML file, `client/index.html`, with a `<div id="root">`; React fills it with the whole interface.

**Q2. Why is there only one HTML file?**
It is a **Single Page Application (SPA)**. The browser loads one page and React changes the content without reloading the page. React Router changes the URL and shows the right component.

**Q3. Which HTML5 features did you use?**
Semantic tags (`<header>`, `<main>`, `<nav>`, `<aside>`, `<section>`), form elements (`<input type="number">`, `type="date"`, `type="email"`, `<select>`, `<textarea>`), the `viewport` meta tag for mobile, and attributes like `aria-label` for accessibility.

### B. CSS

**Q4. How did you make the website responsive?**
With CSS **media queries**. Under 1100 px the cards go from 4 to 2 columns; under 860 px the sidebar hides behind a menu button; under 640 px the tables become stacked cards and forms become one column. I also used Flexbox and CSS Grid, and the `viewport` meta tag.

**Q5. What is the difference between Flexbox and Grid?**
Flexbox arranges items in **one direction** (a row or column) – I used it for the sidebar, toolbars and buttons. Grid arranges items in **rows and columns together** – I used it for the dashboard cards, doctor cards and form layouts.

**Q6. What are CSS variables? Did you use them?**
Variables like `--blue-600` defined in `:root` and used with `var(--blue-600)`. I stored my colour palette there, so changing one value changes the whole theme.

**Q7. How did you choose colours?**
White background and medical blue for trust and cleanliness, with subtle green for health/success. Red is used only for errors and cancel/delete.

### C. JavaScript

**Q8. What JavaScript features did you use?**
`const/let`, arrow functions, template strings, destructuring, spread operator (`{ ...values, [name]: value }`), array methods (`map`, `filter`, `find`, `some`, `sort`), `async/await`, `Promise.all`, and `try/catch`.

**Q9. What is `async/await`?**
A readable way to work with Promises. `await` pauses the function until the server responds, without freezing the page. Example: `const data = await api.get("/patients")`.

**Q10. What is JSON?**
JavaScript Object Notation – a text format for data: `{ "name": "Aarav", "age": 34 }`. `JSON.stringify()` converts an object to text and `JSON.parse()` converts text back to an object. It is used for the database files **and** for sending data between React and Express.

### D. React

**Q11. What is React and why is it used?**
React is a JavaScript library for building user interfaces from small reusable **components**. When data changes, React updates only the part of the screen that needs it.

**Q12. What is a component? Give examples from your project.**
A function that returns JSX (HTML-like code). Examples: `Sidebar`, `StatCard`, `Modal`, `PatientForm`, `Patients` (page). Reusing components avoids repeated code – e.g., `StatusBadge` is used in three pages.

**Q13. What are props?**
Inputs passed from a parent to a child component, like function arguments. Example: `<StatCard title="Total Patients" value={12} />`. Props are **read-only** for the child. `<PatientForm initialData={patient} onSubmit={handleSave} onCancel={closeForm} />` passes both data and functions.

**Q14. What is state? How is it different from props?**
State is data **owned by a component** that can change over time, stored with `useState`. When state changes, React re-renders the component. Props come from outside (parent) and cannot be changed by the child; state belongs to the component itself.

**Q15. Explain `useState` with an example from your code.**
`const [search, setSearch] = useState("")` – `search` holds the current text and `setSearch` changes it. In the search box: `onChange={(e) => setSearch(e.target.value)}`. Every keystroke updates the state and the table re-filters instantly.

**Q16. What is `useEffect`? Why do you use it?**
A hook that runs code after the component renders – I use it to **fetch data when a page opens**. `useEffect(() => { loadPatients(); }, [loadPatients])` – the array is the dependency list; with a stable function it runs once when the page appears. It can also return a cleanup function (used in `Toast` and `Modal` to remove timers and event listeners).

**Q17. What is `useCallback`?**
It remembers a function between renders so its identity doesn't change. I used it for `loadPatients` so `useEffect` doesn't run again unnecessarily.

**Q18. What is JSX?**
A syntax extension that lets us write HTML-like markup inside JavaScript. The build tool converts it into normal JavaScript. In JSX we write `className` instead of `class` and `onClick` instead of `onclick`.

**Q19. What is the `key` prop in lists?**
A unique value (I use the record `id`) that helps React track which list item changed. Example: `patients.map(p => <tr key={p.id}>...)`.

**Q20. What is a controlled form input?**
An input whose value is stored in React state: `value={values.name} onChange={handleChange}`. React is the "single source of truth", which makes validation and editing easy.

**Q21. What is React Router?**
A library for navigation in a single page app. `<Routes>` and `<Route path="/patients" element={<Patients />} />` map URLs to pages; `<NavLink>` creates links without reloading the page and highlights the active one.

**Q22. What is conditional rendering?**
Showing different UI depending on state. Example: `if (loading) return <Loader />; if (error) return <ErrorMessage />;` and `{formOpen && <Modal>...</Modal>}`.

**Q23. What is Vite and why not Create React App?**
Vite is a fast development server and build tool. It starts instantly and reloads quickly. Create React App is no longer maintained, so Vite is the modern recommended choice.

**Q24. What is the virtual DOM?**
A lightweight copy of the page kept in memory. React compares the new copy with the old one and updates only the differences in the real DOM, which is faster.

### E. fetch() and REST APIs

**Q25. What is `fetch()`?**
A built-in browser function to make HTTP requests. It returns a Promise. Example from `api.js`: `fetch(API_URL + path, { method: "POST", headers: {...}, body: JSON.stringify(data) })`. Then `response.json()` reads the reply.

**Q26. Why did you create `services/api.js`?**
So all server calls are in one place: the URL is defined once, error handling is written once, and pages stay short and readable (`api.get("/patients")`).

**Q27. What is a REST API?**
A way for the frontend and backend to talk using HTTP. URLs represent **resources** (`/api/patients`) and HTTP methods represent **actions**: GET = read, POST = create, PUT = update, DELETE = delete.

**Q28. What is the difference between PUT, PATCH and POST?**
POST creates a new record. PUT replaces/updates a record with the full data. PATCH changes only part of a record – I used PATCH for `/appointments/:id/cancel` because it only changes the status.

**Q29. What do the HTTP status codes mean?**
200 OK, 201 Created, 400 Bad Request (validation failed), 404 Not Found, 500 Internal Server Error.

**Q30. What is CORS and why did you need it?**
Browsers block a web page on one "origin" (localhost:5173) from calling an API on another origin (localhost:5000) unless the server allows it. I used the `cors` package in Express to allow my React app.

**Q31. What is the difference between `req.params`, `req.query` and `req.body`?**
`req.params` = values in the URL path (`/patients/:id`). `req.query` = values after `?` (`?search=aarav`). `req.body` = data sent in the request body (form data as JSON).

### F. Node.js, Express.js

**Q32. What is Node.js?**
A runtime that lets us run JavaScript outside the browser, on the computer/server. It lets us use one language for frontend and backend.

**Q33. What is Express.js?**
A small framework for Node.js that makes it easy to create web servers and APIs with routes like `router.get("/", handler)`.

**Q34. What is middleware? Which did you use?**
A function that runs between receiving a request and sending a response. I used `cors()`, `express.json()` (reads JSON bodies), my own request logger, and an error-handling middleware.

**Q35. What is `express.Router()`?**
It lets me split routes into separate files – `patients.js`, `doctors.js`, `appointments.js`, `dashboard.js` – and mount them with `app.use("/api/patients", patientRoutes)`.

**Q36. What is `npm` and `package.json`?**
npm is Node's package manager. `package.json` lists the project's name, scripts (`npm start`) and dependencies (express, react...). `node_modules` is where the downloaded packages are stored.

**Q37. Why are there two `package.json` files?**
The frontend and backend are two separate applications with different dependencies, so each has its own `package.json`.

### G. JSON database and CRUD

**Q38. How does your "database" work?**
Each JSON file is like a table. `readData()` loads the file with `fs.readFileSync` and `JSON.parse`. After a change, `writeData()` saves it with `JSON.stringify` and `fs.writeFileSync`. Only the backend touches these files.

**Q39. What is CRUD? Show it in your project.**
Create (Add patient → POST), Read (list → GET), Update (Edit → PUT), Delete (Delete → DELETE). The same four operations exist for doctors; appointments have create, read, update and cancel.

**Q40. How do you generate unique IDs?**
`generateId()` finds the highest existing number for the prefix and adds one – e.g., the highest patient is `P012`, so the next is `P013`.

**Q41. What validation do you do and why in two places?**
Browser validation gives quick feedback to the user. Server validation protects the data because anyone can send requests to the API without using my form. So both are needed.

**Q42. What business rules did you add for appointments?**
Doctor must be Available, date cannot be in the past, the same doctor cannot be booked twice at the same date and time, completed appointments cannot be cancelled.

**Q43. What happens when a patient is deleted?**
Their appointments are deleted too, so there are no appointments pointing to a person who no longer exists (similar to cascade delete in SQL).

**Q44. How is "available beds" calculated?**
`totalBeds` (20, in `hospital.json`) minus the number of patients whose status is "Admitted".

**Q45. How do you handle loading, errors and empty data?**
Each page has `loading`, `error` and data states. While loading it shows a spinner; if the request fails it shows an error with a **Try again** button; if the list is empty it shows a friendly empty-state message.

### H. Limitations and improvements

**Q46. What are the limitations of using JSON files?**
No security, no transactions, slow with big data, and two users saving at the same time could overwrite each other. It is fine for a demo, not for production.

**Q47. How would you improve the project?**
Use MongoDB or MySQL, add login with JWT and roles, add billing and prescriptions, charts, email reminders, and AI features like symptom-based department suggestion.

**Q48. How would you connect a real database?**
Only the `routes` and `utils/db.js` need to change: instead of reading and writing a file, they would query the database (e.g., with Mongoose for MongoDB). The React frontend would stay the same, because it only talks to the API.

**Q49. Is the data secure?**
No. This is a learning project with dummy data. A real system needs authentication, HTTPS, encryption, access control and compliance with health-data privacy laws.

**Q50. What did you learn?**
How a full stack application is organised, how React and Express communicate, REST API design, state management, validation, responsive design and debugging.

---

## 4. Why did you choose these technologies? (likely faculty questions)

| Question | Answer |
| -------- | ------ |
| Why React? | Component-based and reusable, fast updates, very popular in industry, huge community and many learning resources. |
| Why not plain HTML/JS? | With plain JS I would have to update the page manually after every change; React updates the UI automatically when state changes. |
| Why Node.js + Express? | One language (JavaScript) on both frontend and backend, lightweight, easy to learn, ideal for REST APIs. |
| Why JSON files instead of MySQL/MongoDB? | Zero installation and zero cost, easy to read and explain, and easy to demo on any laptop. The project is designed so the data layer can be swapped later. |
| Why a separate backend? Why not only React + localStorage? | The requirement is real persistence. localStorage is stored only in one browser; a backend stores data centrally so any client sees the same data, and it can enforce rules. |
| Why REST API? | Simple, standard, works with any frontend (web or mobile). |
| Why Vite? | Fast start and reload, officially recommended way to start a React project today. |
| Why React Router? | To have separate pages (URLs) in a single page application. |
| Why `react-icons`? | Free ready-made icons that are used as React components. |
| Why two ports (5173 and 5000)? | The frontend dev server and the backend are separate programs; each needs its own port. CORS connects them. |
| Why separate folders `components`, `pages`, `services`? | Separation of concerns – easier to read, test and maintain. |
| Why validation on both sides? | Browser for user experience, server for security and data integrity. |
| Why is this relevant to AI & ML? | Real AI systems are delivered through web apps and APIs. The same architecture can host a model endpoint (e.g., symptom classifier) later. |

---

## 5. Tips for the viva

- Know **one complete flow** by heart (add patient: form → state → validation → fetch → route → JSON file → response → reload).
- Be able to open and explain **`PatientForm.jsx`**, **`routes/patients.js`** and **`services/api.js`** line by line.
- If you don't know an answer, explain what you *do* know about it; don't guess wildly.
- Be honest: it's a learning project with dummy data and JSON storage – and say how you would improve it.

---

## 6. Final checklist before the college demonstration

**Setup**
- [ ] Node.js installed (`node -v`, `npm -v` work).
- [ ] `npm install` done in both `server` and `client` folders.
- [ ] Original sample data is in `server/data/` (initial counts: 12 patients, 6 doctors, 12 appointments).
- [ ] Backend starts: `Server running at http://localhost:5000`.
- [ ] `http://localhost:5000/api/patients` shows JSON in the browser.
- [ ] Frontend starts and `http://localhost:5173` opens.
- [ ] Laptop charged, charger packed; internet not required.

**Dashboard**
- [ ] Four cards show correct numbers (15 available beds with the original data).
- [ ] Recent appointments table and statistics bars are visible.

**Patients**
- [ ] Table shows all patients.
- [ ] Search by name works; search by ID works; "no matching patients" shows for nonsense.
- [ ] Add patient works; empty form shows errors; invalid age/phone/email show errors.
- [ ] Edit patient works and the change stays after refresh.
- [ ] Delete shows confirmation; "No" keeps the record; "Yes" deletes it.

**Doctors**
- [ ] Cards show name, specialization, availability, schedule, phone, email.
- [ ] Add, edit and delete doctor work.

**Appointments**
- [ ] List shows patient, doctor, date, time, reason, status badge.
- [ ] Book appointment works with valid data.
- [ ] Empty form shows errors.
- [ ] Double-booking, past date and "On Leave" doctor are rejected with messages.
- [ ] Edit/reschedule works; Mark completed works; Cancel (with confirmation) works.
- [ ] Status filter tabs work.

**General**
- [ ] Every sidebar link works; unknown URL shows the 404 page.
- [ ] Data persists after browser refresh **and** after restarting the backend.
- [ ] Stop backend → friendly error appears; restart → "Try again" works.
- [ ] Responsive: sidebar menu and card-style tables work in phone mode (`F12` → device toolbar).
- [ ] No red errors in the browser console (`F12` → Console).

**Preparation**
- [ ] You can explain the architecture diagram.
- [ ] You can explain one full request flow without notes.
- [ ] You practised the 4-minute demo script at least twice.
- [ ] Screenshots and report are printed / saved; project zip and a backup copy are on a pen drive/cloud.
- [ ] You know the limitations and future enhancements.
- [ ] To reset the data before the demo, replace the 3 JSON files in `server/data/` with the originals.
