# Hospital Management System – Project Report Content

*Individual Full Stack Web Development Project – B.Tech CSE (AI & ML), Third Year*

> Copy the sections below into your college report template. Replace the placeholders in square brackets (your name, roll number, guide name). The "Actual Result" column of the test table is left empty on purpose – fill it in after you run each test yourself.

---

## 1. Abstract

The Hospital Management System is a full stack web application that helps a hospital manage its daily records digitally. It provides a dashboard with key statistics and modules to manage patients, doctors and appointments. The frontend is built with HTML5, CSS3, JavaScript and React.js. The backend is built with Node.js and Express.js and exposes a REST API. Data is stored in JSON files that act as a dummy database, and every add, edit, delete or cancel operation is saved permanently by the backend. The system includes form validation, search, status tracking, responsive design for desktop and mobile, and protection against invalid actions such as double-booking a doctor. The project demonstrates the complete flow of a modern web application: user interface → API request → server logic → data storage → response.

## 2. Problem Statement

Many small clinics and hospitals still record patient details, doctor schedules and appointments on paper registers or in scattered spreadsheets. This causes:

- time wasted searching for records,
- duplicate or incorrect entries,
- appointment clashes (two patients booked with the same doctor at the same time),
- no quick overview of how many patients, doctors, appointments and free beds there are.

A simple, easy-to-use web application is needed that keeps all this information in one place and keeps it consistent.

## 3. Objectives

1. Build a responsive web interface for hospital staff using React.js.
2. Provide complete CRUD (Create, Read, Update, Delete) operations for patients and doctors.
3. Allow booking, updating, completing and cancelling of appointments with clash prevention.
4. Show a dashboard with total patients, doctors, appointments, available beds and recent activity.
5. Implement a REST API using Node.js and Express.js.
6. Store data permanently in JSON files through the backend.
7. Validate all forms on the client and the server to avoid invalid data.
8. Apply good practices: reusable components, separation of concerns, clear error handling.

## 4. Existing System and Proposed System

### Existing system (manual / spreadsheet based)

| Aspect | Problem |
| ------ | ------- |
| Records | Paper files or separate Excel sheets |
| Searching | Slow, manual |
| Appointments | Booked by phone/notebook, clashes are common |
| Statistics | Counted by hand |
| Errors | No validation, typing mistakes remain |
| Access | Only one person can use a register at a time |

### Proposed system

| Aspect | Solution |
| ------ | -------- |
| Records | Centralised, stored in JSON files through the backend |
| Searching | Instant search by patient name or ID |
| Appointments | Booking form with validation; same doctor/date/time cannot be booked twice |
| Statistics | Dashboard calculated automatically by the API |
| Errors | Validation in the browser and on the server |
| Access | Web interface usable on desktop, tablet and mobile |

## 5. Software and Hardware Requirements

### Software

| Item | Version / detail |
| ---- | ---------------- |
| Operating system | Windows 10 / 11 |
| Node.js | LTS 18 or newer (includes npm) |
| Frontend | React 18, React Router 6, Vite 5, react-icons |
| Backend | Express 4, cors |
| Editor | Visual Studio Code |
| Browser | Google Chrome / Microsoft Edge (latest) |
| Terminal | Windows PowerShell |

### Hardware (minimum)

| Item | Requirement |
| ---- | ----------- |
| Processor | Dual-core, 2 GHz or better |
| RAM | 4 GB (8 GB recommended) |
| Storage | 500 MB free (mostly for `node_modules`) |
| Internet | Needed only once for `npm install` |

## 6. System Architecture

The system uses a **three-tier architecture**:

```
┌────────────────────────┐      HTTP (JSON)       ┌────────────────────────┐      fs read/write     ┌────────────────────┐
│  PRESENTATION TIER     │  ───────────────────►  │  APPLICATION TIER      │  ───────────────────►  │  DATA TIER         │
│  React.js app          │   fetch() requests     │  Node.js + Express.js  │   readData/writeData   │  JSON files        │
│  http://localhost:5173 │  ◄───────────────────  │  http://localhost:5000 │  ◄───────────────────  │  patients.json     │
│  HTML + CSS + JS       │   JSON responses       │  REST API, validation  │                        │  doctors.json      │
└────────────────────────┘                        └────────────────────────┘                        │  appointments.json │
                                                                                                    │  hospital.json     │
                                                                                                    └────────────────────┘
```

- **Presentation tier:** pages, forms, tables, sidebar. Runs in the browser.
- **Application tier:** receives requests, validates them, applies business rules (e.g., no double booking), reads/writes data.
- **Data tier:** four JSON files in `server/data/`.
- **CORS** is enabled on the server so the browser allows the React app (port 5173) to call the API (port 5000).

## 7. Module Descriptions

### 7.1 Dashboard module
Shows four summary cards (patients, doctors, appointments, available beds), the five most recent appointments, bed occupancy, appointments by status, patients by status and doctor availability. Data comes from `GET /api/dashboard`. Available beds = total beds − number of admitted patients.

### 7.2 Patient management module
Add patient (form), list patients (table), search by name or ID, edit patient (same form, pre-filled), delete patient (confirmation dialog). Deleting a patient also removes that patient's appointments so no orphan records remain.

### 7.3 Doctor management module
Doctors are shown as cards with name, specialization, availability badge, working schedule, phone and email. Add, edit and delete are supported. Deleting a doctor removes that doctor's appointments.

### 7.4 Appointment management module
Book an appointment by choosing patient, doctor, date, time and reason. Status can be Scheduled, Completed or Cancelled. Staff can edit an appointment, mark it completed, or cancel it (after confirmation). Business rules:
- the doctor must be "Available",
- the date cannot be in the past,
- the same doctor cannot have two scheduled appointments at the same date and time,
- completed appointments cannot be cancelled.

### 7.5 Common/UI module
Reusable components: Sidebar, Modal, ConfirmDialog, Toast, Loader, EmptyState, ErrorMessage, StatusBadge, StatCard, FormField, PageHeader.

## 8. Data Flow Explanation

### Level 0 (context)

```
Hospital Staff ──(enter / view data)──►  [ Hospital Management System ]  ──(reports, lists, statistics)──► Hospital Staff
```

### Level 1 (example: booking an appointment)

1. Staff opens **Appointments** page → React calls `GET /api/appointments`, `GET /api/patients`, `GET /api/doctors`.
2. Staff clicks **Book Appointment**, fills the form. The browser validates it (required fields, date not in past).
3. React sends `POST /api/appointments` with the form data as JSON.
4. Express validates again, checks the patient and doctor exist, doctor availability and clash rule.
5. If valid: the server generates an ID (`A013`), appends the record to `appointments.json` and replies `201 Created`.
6. If invalid: the server replies `400` with field-level error messages; the form shows them in red.
7. React closes the form, shows a success toast and reloads the list.

### Other flows
- **Add/Edit/Delete patient or doctor** follow the same pattern (`POST`, `PUT`, `DELETE`).
- **Dashboard** → the server reads all JSON files, counts and sends one summary object.

## 9. Database / JSON Schema

There is no SQL database; four JSON files are used.

### 9.1 `patients.json` (array)

| Field | Type | Example | Rule |
| ----- | ---- | ------- | ---- |
| id | string | `"P001"` | unique, auto-generated |
| name | string | `"Aarav Mehta"` | min 2 characters |
| age | number | `34` | whole number 0–120 |
| gender | string | `"Male"` | Male / Female / Other |
| phone | string | `"+91 90000 10001"` | 7–15 digits, `+`, `-`, space |
| email | string | `"aarav.mehta@example.com"` | optional, valid format |
| address | string | `"12 Lake View Road"` | optional |
| bloodGroup | string | `"A+"` | A+, A-, B+, B-, AB+, AB-, O+, O- |
| condition | string | `"Hypertension"` | required |
| status | string | `"Outpatient"` | Outpatient / Admitted / Discharged |
| registeredOn | string | `"2026-09-01"` | set by server |

### 9.2 `doctors.json` (array)

| Field | Type | Example | Rule |
| ----- | ---- | ------- | ---- |
| id | string | `"D001"` | unique, auto-generated |
| name | string | `"Dr. Priya Raman"` | min 2 characters |
| specialization | string | `"Cardiology"` | required |
| phone | string | `"+91 90000 20001"` | valid phone |
| email | string | `"priya.raman@cityhospital.example"` | valid email |
| availability | string | `"Available"` | Available / Unavailable / On Leave |
| schedule | string | `"Mon - Fri, 9 AM - 4 PM"` | required |
| experience | number | `15` | whole number 0–60 |

### 9.3 `appointments.json` (array)

| Field | Type | Example | Rule |
| ----- | ---- | ------- | ---- |
| id | string | `"A001"` | unique, auto-generated |
| patientId | string | `"P001"` | must exist in patients.json |
| doctorId | string | `"D001"` | must exist in doctors.json |
| date | string | `"2026-10-05"` | `YYYY-MM-DD`, real date |
| time | string | `"10:00"` | `HH:MM` 24-hour |
| reason | string | `"Blood pressure follow-up"` | min 3 characters |
| status | string | `"Completed"` | Scheduled / Completed / Cancelled |

`patientId` and `doctorId` act like **foreign keys**. The API adds `patientName`, `doctorName` and `specialization` when it sends appointments to the browser (they are not stored).

### 9.4 `hospital.json` (object)

```json
{ "name": "City Care Hospital (Demo)", "totalBeds": 20, "departments": ["Cardiology", "..."] }
```

### 9.5 Sample dummy data
12 patients, 6 doctors, 12 appointments, all fictional (`example.com` emails, `+91 90000 xxxxx` phone numbers).

## 10. Implementation Details

### 10.1 Frontend
- **React + Vite.** `main.jsx` mounts `<App />` inside `<BrowserRouter>`.
- **Routing:** `react-router-dom` – routes `/`, `/patients`, `/doctors`, `/appointments`, and `*` for 404. `NavLink` highlights the active menu item.
- **State & hooks:** `useState` stores lists, form values, errors, loading flags. `useEffect` loads data when a page opens. `useCallback` keeps the loader function stable.
- **Props:** parent pages pass data and functions to child components (e.g., `PatientForm initialData onSubmit onCancel`).
- **API layer:** `services/api.js` wraps `fetch()` and converts failures into readable error messages.
- **Validation:** `utils/helpers.js` has one validation function per form. Errors are shown below each field.
- **Styling:** one `index.css` using CSS variables for the colour palette, Flexbox and Grid for layout, and `@media` queries for responsiveness (sidebar collapses under 860 px, tables become cards under 640 px).

### 10.2 Backend
- `server.js` creates the Express app, enables `cors()` and `express.json()`, logs requests, mounts the four routers and adds a 404 handler and a global error handler.
- `routes/*.js` hold the endpoints. `utils/db.js` reads/writes JSON with Node's `fs` module and generates IDs (`P013`, `D007`, ...). `utils/validate.js` contains server-side validation.
- HTTP status codes: 200, 201, 400, 404, 500.

### 10.3 How the pieces connect
React page → `api.get/post/put/delete` → `fetch()` → Express route → validate → `readData`/`writeData` → JSON file → JSON response → React updates state → screen re-renders.

## 11. Test Cases and Expected Results

Run each test yourself and write what you observed in the last column.

| # | Module | Test case / steps | Expected result | Actual result |
| - | ------ | ----------------- | --------------- | ------------- |
| 1 | Dashboard | Open `http://localhost:5173` | Four cards show 12 patients, 6 doctors, 12 appointments, 15 available beds (initial data); recent appointments list appears | |
| 2 | Navigation | Click each sidebar link | Each page opens; active link is highlighted | |
| 3 | Patient add | Add a valid patient | Success message; new row appears with ID `P013`; `patients.json` contains it | |
| 4 | Patient validation | Submit the add form empty | Red error messages under required fields; nothing saved | |
| 5 | Patient validation | Enter age `200`, phone `12`, email `abc` | Errors for age, phone and email | |
| 6 | Patient search | Type `aarav` | Only Aarav Mehta is listed | |
| 7 | Patient search | Type `P003` | Only Rohan Iyer is listed | |
| 8 | Patient search | Type `zzzz` | "No matching patients" message | |
| 9 | Patient edit | Edit a patient's condition and save | Table shows new value; file updated; value remains after refresh | |
| 10 | Patient delete | Click delete → "No, go back" | Nothing is deleted | |
| 11 | Patient delete | Click delete → "Yes, delete" | Row disappears; patient's appointments also disappear | |
| 12 | Doctor add | Add a valid doctor | New doctor card appears (`D007`) | |
| 13 | Doctor edit | Change availability to "On Leave" | Badge turns orange | |
| 14 | Doctor delete | Delete a doctor after confirming | Card removed, their appointments removed | |
| 15 | Appointment book | Book valid appointment (future date, available doctor) | Success message; status "Scheduled" | |
| 16 | Appointment validation | Submit booking form empty | Errors for patient, doctor, date, time, reason | |
| 17 | Appointment past date | Choose a past date (type it manually) | "Appointment date cannot be in the past" | |
| 18 | Double booking | Book same doctor, date and time again | Error: doctor already has an appointment at that time | |
| 19 | Unavailable doctor | Book with a doctor marked "On Leave" | Error: doctor is currently on leave | |
| 20 | Appointment update | Edit time or reason | Updated row shown | |
| 21 | Appointment complete | Click the green tick on a Scheduled appointment | Status becomes Completed; tick/cancel buttons disappear | |
| 22 | Appointment cancel | Click cancel → confirm | Status becomes Cancelled | |
| 23 | Status filter | Click Scheduled / Completed / Cancelled tabs | Only matching appointments shown | |
| 24 | Persistence | Add a record, refresh browser, then restart backend | Record is still there | |
| 25 | Error handling | Stop backend, refresh the page | "Cannot connect to the server" message with "Try again"; after restarting backend, "Try again" loads data | |
| 26 | Empty state | Delete all appointments (or filter with no results) | Friendly "No appointments" message | |
| 27 | Responsive | Resize browser below 860 px / use DevTools phone mode | Sidebar hides behind the menu button; tables become cards | |
| 28 | 404 page | Open `http://localhost:5173/abc` | "Page not found" with a link back to the dashboard | |
| 29 | API | Open `http://localhost:5000/api/doctors` | JSON list of doctors | |
| 30 | API error | Open `http://localhost:5000/api/patients/P999` | `{"message":"Patient not found."}` | |

## 12. Advantages and Limitations

### Advantages
- Easy to understand: small, well-separated files.
- Complete CRUD with real persistence through a backend.
- Validation on both client and server.
- Responsive, modern, medical-themed interface.
- Free: no paid database or API; works offline after installation.
- Reusable components reduce repeated code.

### Limitations
- JSON files are not a real database: no transactions, slow for large data, and two simultaneous writes could conflict.
- No login or role-based access (admin, doctor, receptionist).
- No encryption or privacy compliance, so it must **not** be used with real patient data.
- Only basic search (patients) and filtering (appointments).
- No billing, pharmacy, lab or inventory modules.
- No automated tests included.

## 13. Future Enhancements

1. Replace JSON files with MongoDB, MySQL or PostgreSQL.
2. Add authentication (JWT) and roles: admin, doctor, receptionist, patient.
3. Add billing, prescriptions, lab reports and medical history.
4. Email/SMS reminders for appointments.
5. Charts using a library such as Chart.js or Recharts; downloadable PDF reports.
6. Doctor-wise calendar view and automatic free-slot detection.
7. AI features (suits your AI & ML branch): symptom-based department suggestion, appointment no-show prediction, patient-load forecasting.
8. Automated tests (Jest, React Testing Library, Supertest) and deployment on a cloud platform.
9. Pagination and sorting for large tables.

## 14. Conclusion

The Hospital Management System demonstrates a complete full stack workflow using React.js, Node.js, Express.js and JSON storage. It replaces manual record keeping with a simple digital system for patients, doctors and appointments, prevents common mistakes through validation and business rules, and presents information through a responsive dashboard. The project strengthens understanding of component-based UI design, REST APIs, client–server communication and CRUD operations, and it can be extended into a production-grade system by adding a real database, authentication and more modules.

---

## Appendix A – How to take screenshots for the report

Run the app first (backend + frontend) and use the **initial sample data** so the screens look rich.

**Windows shortcuts**
- `Windows + Shift + S` → choose "Rectangular snip" → drag over the browser area → the image is copied; paste it into Word/Docs. 
- Or press `Windows + PrtScn` to save a full-screen image into `Pictures\Screenshots`.
- For a scrolling/full page: in Chrome press `F12` → `Ctrl + Shift + P` → type **"screenshot"** → choose **Capture full size screenshot**.
- For the mobile view: `F12` → click the phone/tablet icon (Toggle device toolbar) → choose "iPhone 12 Pro" → take the screenshot.

**Recommended screenshots (with figure captions)**

| Fig. | Screen |
| ---- | ------ |
| 1 | Dashboard (full page) |
| 2 | Patients list with search result (e.g. `aarav`) |
| 3 | Add Patient form with validation errors |
| 4 | Edit Patient form (pre-filled) |
| 5 | Delete confirmation dialog |
| 6 | Doctors page |
| 7 | Add / Edit Doctor form |
| 8 | Appointments list with status badges |
| 9 | Book Appointment form |
| 10 | Double-booking error message |
| 11 | Cancel appointment confirmation |
| 12 | Mobile view with sidebar open |
| 13 | Backend terminal showing `Server running at http://localhost:5000` and request logs |
| 14 | Browser showing `http://localhost:5000/api/patients` JSON |
| 15 | VS Code folder structure (Explorer panel) |
| 16 | One JSON file open in VS Code (e.g. `patients.json`) |

**Tips:** use a clean browser window (hide bookmarks bar), zoom to 100%, crop out your personal information, name files `fig01-dashboard.png` etc., and label every figure in the report (e.g., "Fig. 3: Patient form validation").
