import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The React app runs on port 5173. The backend API runs on port 5000.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true, // show an error instead of silently using another port (CORS allows only 5173)
  },
});
