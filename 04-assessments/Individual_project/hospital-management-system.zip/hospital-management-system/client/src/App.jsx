import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import { FaBars, FaHospitalAlt } from "react-icons/fa";
import Sidebar from "./components/Sidebar.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Patients from "./pages/Patients.jsx";
import Doctors from "./pages/Doctors.jsx";
import Appointments from "./pages/Appointments.jsx";
import NotFound from "./pages/NotFound.jsx";

// App = the layout (sidebar + page area) and the list of routes.
function App() {
  const [menuOpen, setMenuOpen] = useState(false); // mobile menu open/closed

  return (
    <div className="app-layout">
      <Sidebar isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <div className="main-area">
        {/* Top bar - only visible on small screens */}
        <header className="mobile-topbar">
          <button className="icon-btn" onClick={() => setMenuOpen(true)} aria-label="Open menu">
            <FaBars />
          </button>
          <FaHospitalAlt className="brand-icon-small" />
          <span>City Care Hospital</span>
        </header>

        <main className="content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/patients" element={<Patients />} />
            <Route path="/doctors" element={<Doctors />} />
            <Route path="/appointments" element={<Appointments />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default App;
