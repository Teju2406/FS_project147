// helpers.js - small reusable functions and constants used across the app.

export const GENDERS = ["Male", "Female", "Other"];
export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
export const PATIENT_STATUSES = ["Outpatient", "Admitted", "Discharged"];
export const DOCTOR_AVAILABILITY = ["Available", "Unavailable", "On Leave"];
export const APPOINTMENT_STATUSES = ["Scheduled", "Completed", "Cancelled"];

// Time slots every 30 minutes from 09:00 to 16:30 -> ["09:00", "09:30", ...]
export const TIME_SLOTS = (() => {
  const slots = [];
  for (let hour = 9; hour <= 16; hour++) {
    slots.push(String(hour).padStart(2, "0") + ":00");
    slots.push(String(hour).padStart(2, "0") + ":30");
  }
  return slots;
})();

// "2026-10-18" -> "18 Oct 2026"
export function formatDate(dateString) {
  if (!dateString) return "";
  const [year, month, day] = dateString.split("-").map(Number);
  return new Date(year, month - 1, day).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

// "14:30" -> "2:30 PM"
export function formatTime(timeString) {
  if (!timeString) return "";
  const [hour, minute] = timeString.split(":").map(Number);
  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${String(minute).padStart(2, "0")} ${suffix}`;
}

// Today's date as "YYYY-MM-DD" in local time (used as the minimum for the date picker)
export function todayString() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

// ---- Form validation (runs in the browser BEFORE sending data to the server) ----
const PHONE_REGEX = /^[0-9+\-\s]{7,15}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isWholeNumberBetween(value, min, max) {
  if (value === "" || value === null || value === undefined) return false;
  const number = Number(value);
  return Number.isInteger(number) && number >= min && number <= max;
}

export function validatePatientForm(values) {
  const errors = {};
  if (!values.name.trim() || values.name.trim().length < 2) errors.name = "Name must be at least 2 characters.";
  if (!isWholeNumberBetween(values.age, 0, 120)) errors.age = "Age must be a whole number between 0 and 120.";
  if (!values.gender) errors.gender = "Please select a gender.";
  if (!PHONE_REGEX.test(values.phone.trim())) errors.phone = "Enter a valid phone number (7-15 digits).";
  if (values.email.trim() && !EMAIL_REGEX.test(values.email.trim())) errors.email = "Enter a valid email address.";
  if (!values.bloodGroup) errors.bloodGroup = "Please select a blood group.";
  if (!values.condition.trim()) errors.condition = "Condition / diagnosis is required.";
  if (!values.status) errors.status = "Please select a status.";
  return errors;
}

export function validateDoctorForm(values) {
  const errors = {};
  if (!values.name.trim() || values.name.trim().length < 2) errors.name = "Name must be at least 2 characters.";
  if (!values.specialization.trim()) errors.specialization = "Specialization is required.";
  if (!PHONE_REGEX.test(values.phone.trim())) errors.phone = "Enter a valid phone number (7-15 digits).";
  if (!EMAIL_REGEX.test(values.email.trim())) errors.email = "Enter a valid email address.";
  if (!values.availability) errors.availability = "Please select availability.";
  if (!values.schedule.trim()) errors.schedule = "Working schedule is required.";
  if (!isWholeNumberBetween(values.experience, 0, 60)) errors.experience = "Experience must be a whole number between 0 and 60.";
  return errors;
}

export function validateAppointmentForm(values, isEditing) {
  const errors = {};
  if (!values.patientId) errors.patientId = "Please select a patient.";
  if (!values.doctorId) errors.doctorId = "Please select a doctor.";
  if (!values.date) {
    errors.date = "Please choose a date.";
  } else if (!isEditing && values.date < todayString()) {
    errors.date = "Appointment date cannot be in the past.";
  }
  if (!values.time) errors.time = "Please choose a time.";
  if (!values.reason.trim() || values.reason.trim().length < 3) errors.reason = "Reason must be at least 3 characters.";
  return errors;
}
