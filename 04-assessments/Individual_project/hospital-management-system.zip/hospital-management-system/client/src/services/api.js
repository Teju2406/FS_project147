// api.js - ONE place for all calls to the backend using fetch().
// Pages never call fetch() directly; they use api.get / api.post / ...

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(API_URL + path, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch (networkError) {
    // fetch() throws only when the server cannot be reached at all
    throw new Error(
      "Cannot connect to the server. Please check that the backend is running on port 5000."
    );
  }

  let data = null;
  try {
    data = await response.json();
  } catch (e) {
    // response had no JSON body - ignore
  }

  if (!response.ok) {
    const error = new Error((data && data.message) || "Request failed.");
    error.errors = data && data.errors; // field-level errors from the server
    throw error;
  }
  return data;
}

export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: "POST", body: JSON.stringify(body) }),
  put: (path, body) => request(path, { method: "PUT", body: JSON.stringify(body) }),
  patch: (path) => request(path, { method: "PATCH" }),
  delete: (path) => request(path, { method: "DELETE" }),
};
