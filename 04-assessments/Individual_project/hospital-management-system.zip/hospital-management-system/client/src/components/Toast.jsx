import { useEffect } from "react";

// Small message that appears in the corner and disappears after 3 seconds.
// Props: message, type ("success" | "error"), onClose
function Toast({ message, type = "success", onClose }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer); // cleanup if the component goes away early
  }, [message, onClose]);

  return <div className={`toast toast-${type}`}>{message}</div>;
}

export default Toast;
