// A small card showing one number (used on the Dashboard).
// Props: title, value, icon, color ("blue" | "green" | "teal" | "orange"), note (optional small text)
function StatCard({ title, value, icon, color = "blue", note }) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${color}`}>{icon}</div>
      <div>
        <p className="stat-title">{title}</p>
        <p className="stat-value">{value}</p>
        {note && <p className="stat-note">{note}</p>}
      </div>
    </div>
  );
}

export default StatCard;
