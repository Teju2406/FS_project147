import { NavLink } from "react-router-dom";
import {
  FaHospitalAlt,
  FaTachometerAlt,
  FaUserInjured,
  FaUserMd,
  FaCalendarCheck,
  FaTimes,
} from "react-icons/fa";

// Navigation links shown in the sidebar
const links = [
  { to: "/", label: "Dashboard", icon: <FaTachometerAlt /> },
  { to: "/patients", label: "Patients", icon: <FaUserInjured /> },
  { to: "/doctors", label: "Doctors", icon: <FaUserMd /> },
  { to: "/appointments", label: "Appointments", icon: <FaCalendarCheck /> },
];

// Props: isOpen (is the mobile menu open?), onClose (function to close it)
function Sidebar({ isOpen, onClose }) {
  return (
    <>
      {/* Dark overlay behind the menu on mobile */}
      {isOpen && <div className="sidebar-overlay" onClick={onClose}></div>}

      <aside className={`sidebar ${isOpen ? "open" : ""}`}>
        <div className="sidebar-brand">
          <FaHospitalAlt className="brand-icon" />
          <div>
            <h1>City Care</h1>
            <span>Hospital Management</span>
          </div>
          <button className="sidebar-close" onClick={onClose} aria-label="Close menu">
            <FaTimes />
          </button>
        </div>

        <nav className="sidebar-nav">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === "/"}
              onClick={onClose}
              className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}
            >
              {link.icon}
              <span>{link.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">Demo project - dummy data only</div>
      </aside>
    </>
  );
}

export default Sidebar;
