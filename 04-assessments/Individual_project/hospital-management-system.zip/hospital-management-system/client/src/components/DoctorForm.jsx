import { useState } from "react";
import FormField from "./FormField.jsx";
import { DOCTOR_AVAILABILITY, validateDoctorForm } from "../utils/helpers.js";

const emptyDoctor = {
  name: "",
  specialization: "",
  phone: "",
  email: "",
  availability: "Available",
  schedule: "",
  experience: "",
};

// Add / Edit doctor form.
// Props: initialData (doctor to edit, or null), onSubmit (async), onCancel
function DoctorForm({ initialData, onSubmit, onCancel }) {
  const [values, setValues] = useState({ ...emptyDoctor, ...initialData });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [saving, setSaving] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setValues({ ...values, [name]: value });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setServerError("");

    const foundErrors = validateDoctorForm(values);
    setErrors(foundErrors);
    if (Object.keys(foundErrors).length > 0) return;

    setSaving(true);
    try {
      await onSubmit(values);
    } catch (err) {
      setServerError(err.message);
      if (err.errors) setErrors(err.errors);
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      {serverError && <div className="form-error">{serverError}</div>}

      <div className="form-grid">
        <FormField label="Doctor name" error={errors.name} required>
          <input name="name" value={values.name} onChange={handleChange} placeholder="e.g. Dr. Asha Patel" />
        </FormField>

        <FormField label="Specialization" error={errors.specialization} required>
          <input name="specialization" value={values.specialization} onChange={handleChange} placeholder="e.g. Cardiology" />
        </FormField>

        <FormField label="Phone" error={errors.phone} required>
          <input name="phone" value={values.phone} onChange={handleChange} placeholder="+91 90000 00000" />
        </FormField>

        <FormField label="Email" error={errors.email} required>
          <input name="email" type="email" value={values.email} onChange={handleChange} placeholder="name@cityhospital.example" />
        </FormField>

        <FormField label="Availability" error={errors.availability} required>
          <select name="availability" value={values.availability} onChange={handleChange}>
            {DOCTOR_AVAILABILITY.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Experience (years)" error={errors.experience} required>
          <input name="experience" type="number" min="0" max="60" value={values.experience} onChange={handleChange} />
        </FormField>
      </div>

      <FormField label="Working schedule" error={errors.schedule} required>
        <input name="schedule" value={values.schedule} onChange={handleChange} placeholder="e.g. Mon - Fri, 9 AM - 4 PM" />
      </FormField>

      <div className="form-actions">
        <button type="button" className="btn btn-outline" onClick={onCancel} disabled={saving}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving..." : initialData ? "Update doctor" : "Add doctor"}
        </button>
      </div>
    </form>
  );
}

export default DoctorForm;
