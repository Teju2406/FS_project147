import { useState } from "react";
import FormField from "./FormField.jsx";
import {
  APPOINTMENT_STATUSES,
  TIME_SLOTS,
  formatTime,
  todayString,
  validateAppointmentForm,
} from "../utils/helpers.js";

const emptyAppointment = {
  patientId: "",
  doctorId: "",
  date: "",
  time: "",
  reason: "",
  status: "Scheduled",
};

// Book / Update appointment form.
// Props: initialData (appointment to edit, or null), patients, doctors (lists for the dropdowns),
//        onSubmit (async), onCancel
function AppointmentForm({ initialData, patients, doctors, onSubmit, onCancel }) {
  const isEditing = Boolean(initialData);
  const [values, setValues] = useState({ ...emptyAppointment, ...initialData });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [saving, setSaving] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setValues({ ...values, [name]: value });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setServerError("");

    const foundErrors = validateAppointmentForm(values, isEditing);
    setErrors(foundErrors);
    if (Object.keys(foundErrors).length > 0) return;

    setSaving(true);
    try {
      await onSubmit(values);
    } catch (err) {
      setServerError(err.message);
      if (err.errors) setErrors(err.errors);
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      {serverError && <div className="form-error">{serverError}</div>}

      <div className="form-grid">
        <FormField label="Patient" error={errors.patientId} required>
          <select name="patientId" value={values.patientId} onChange={handleChange}>
            <option value="">Select patient</option>
            {patients.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.id})
              </option>
            ))}
          </select>
        </FormField>

        <FormField label="Doctor" error={errors.doctorId} required>
          <select name="doctorId" value={values.doctorId} onChange={handleChange}>
            <option value="">Select doctor</option>
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} - {d.specialization} ({d.availability})
              </option>
            ))}
          </select>
        </FormField>

        <FormField label="Date" error={errors.date} required>
          <input
            name="date"
            type="date"
            min={isEditing ? undefined : todayString()}
            value={values.date}
            onChange={handleChange}
          />
        </FormField>

        <FormField label="Time" error={errors.time} required>
          <select name="time" value={values.time} onChange={handleChange}>
            <option value="">Select time</option>
            {TIME_SLOTS.map((slot) => (
              <option key={slot} value={slot}>{formatTime(slot)}</option>
            ))}
          </select>
        </FormField>
      </div>

      <FormField label="Reason for visit" error={errors.reason} required>
        <textarea name="reason" rows="2" value={values.reason} onChange={handleChange} />
      </FormField>

      {/* Status can only be changed when editing; new appointments are always "Scheduled" */}
      {isEditing && (
        <FormField label="Status" error={errors.status}>
          <select name="status" value={values.status} onChange={handleChange}>
            {APPOINTMENT_STATUSES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </FormField>
      )}

      <div className="form-actions">
        <button type="button" className="btn btn-outline" onClick={onCancel} disabled={saving}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving..." : isEditing ? "Update appointment" : "Book appointment"}
        </button>
      </div>
    </form>
  );
}

export default AppointmentForm;
