// Coloured pill for a status value such as "Scheduled" or "Available".
// "On Leave" becomes the CSS class "badge-on-leave".
function StatusBadge({ status }) {
  const className = "badge badge-" + status.toLowerCase().replace(/\s+/g, "-");
  return <span className={className}>{status}</span>;
}

export default StatusBadge;
