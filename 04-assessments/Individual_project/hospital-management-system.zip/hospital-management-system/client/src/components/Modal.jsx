import { useEffect } from "react";
import { FaTimes } from "react-icons/fa";

// A pop-up window. Used for the Add / Edit forms.
// Props: title, onClose (function), children (the content inside)
function Modal({ title, onClose, children }) {
  // Close the modal when the user presses the Escape key
  useEffect(() => {
    function handleKey(event) {
      if (event.key === "Escape") onClose();
    }
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      {/* stopPropagation: clicking inside the box must not close it */}
      <div className="modal" role="dialog" aria-modal="true" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>{title}</h3>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <FaTimes />
          </button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

export default Modal;
