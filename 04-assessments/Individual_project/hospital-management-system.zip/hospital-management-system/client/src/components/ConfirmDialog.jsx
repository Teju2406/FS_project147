import Modal from "./Modal.jsx";

// "Are you sure?" dialog used before deleting / cancelling.
// Props: title, message, confirmText, onConfirm, onCancel, loading
function ConfirmDialog({ title, message, confirmText = "Delete", onConfirm, onCancel, loading }) {
  return (
    <Modal title={title} onClose={onCancel}>
      <p className="confirm-message">{message}</p>
      <div className="form-actions">
        <button className="btn btn-outline" onClick={onCancel} disabled={loading}>
          No, go back
        </button>
        <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
          {loading ? "Please wait..." : confirmText}
        </button>
      </div>
    </Modal>
  );
}

export default ConfirmDialog;
