// A label + input area + error message. Wraps any <input>, <select> or <textarea>.
// Props: label, error, required, children
function FormField({ label, error, required, children }) {
  return (
    <div className={`form-field ${error ? "has-error" : ""}`}>
      <label>
        {label} {required && <span className="required">*</span>}
      </label>
      {children}
      {error && <small className="field-error">{error}</small>}
    </div>
  );
}

export default FormField;
