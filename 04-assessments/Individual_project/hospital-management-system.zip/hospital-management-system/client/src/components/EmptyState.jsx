// Friendly message shown when a list has no records.
// Props: icon, title, text
function EmptyState({ icon, title, text }) {
  return (
    <div className="empty-state">
      {icon && <div className="empty-icon">{icon}</div>}
      <h3>{title}</h3>
      {text && <p>{text}</p>}
    </div>
  );
}

export default EmptyState;
