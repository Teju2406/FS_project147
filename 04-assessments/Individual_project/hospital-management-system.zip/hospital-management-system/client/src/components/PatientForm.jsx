import { useState } from "react";
import FormField from "./FormField.jsx";
import {
  GENDERS,
  BLOOD_GROUPS,
  PATIENT_STATUSES,
  validatePatientForm,
} from "../utils/helpers.js";

const emptyPatient = {
  name: "",
  age: "",
  gender: "",
  phone: "",
  email: "",
  address: "",
  bloodGroup: "",
  condition: "",
  status: "Outpatient",
};

// Add / Edit patient form.
// Props: initialData (patient to edit, or null for a new one),
//        onSubmit (async function that saves), onCancel
function PatientForm({ initialData, onSubmit, onCancel }) {
  // useState keeps the current form values; fall back to empty strings for missing fields
  const [values, setValues] = useState({ ...emptyPatient, ...initialData });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [saving, setSaving] = useState(false);

  // Runs on every keystroke: copies the typed value into state
  function handleChange(event) {
    const { name, value } = event.target;
    setValues({ ...values, [name]: value });
  }

  async function handleSubmit(event) {
    event.preventDefault(); // stop the browser from reloading the page
    setServerError("");

    const foundErrors = validatePatientForm(values);
    setErrors(foundErrors);
    if (Object.keys(foundErrors).length > 0) return; // stop if the form is invalid

    setSaving(true);
    try {
      await onSubmit(values);
    } catch (err) {
      setServerError(err.message);
      if (err.errors) setErrors(err.errors);
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      {serverError && <div className="form-error">{serverError}</div>}

      <div className="form-grid">
        <FormField label="Full name" error={errors.name} required>
          <input name="name" value={values.name} onChange={handleChange} placeholder="e.g. Rahul Sharma" />
        </FormField>

        <FormField label="Age" error={errors.age} required>
          <input name="age" type="number" min="0" max="120" value={values.age} onChange={handleChange} />
        </FormField>

        <FormField label="Gender" error={errors.gender} required>
          <select name="gender" value={values.gender} onChange={handleChange}>
            <option value="">Select gender</option>
            {GENDERS.map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Blood group" error={errors.bloodGroup} required>
          <select name="bloodGroup" value={values.bloodGroup} onChange={handleChange}>
            <option value="">Select blood group</option>
            {BLOOD_GROUPS.map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
        </FormField>

        <FormField label="Phone" error={errors.phone} required>
          <input name="phone" value={values.phone} onChange={handleChange} placeholder="+91 90000 00000" />
        </FormField>

        <FormField label="Email" error={errors.email}>
          <input name="email" type="email" value={values.email} onChange={handleChange} placeholder="name@example.com" />
        </FormField>

        <FormField label="Condition / diagnosis" error={errors.condition} required>
          <input name="condition" value={values.condition} onChange={handleChange} placeholder="e.g. Asthma" />
        </FormField>

        <FormField label="Status" error={errors.status} required>
          <select name="status" value={values.status} onChange={handleChange}>
            {PATIENT_STATUSES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </FormField>
      </div>

      <FormField label="Address" error={errors.address}>
        <textarea name="address" rows="2" value={values.address} onChange={handleChange} />
      </FormField>

      <div className="form-actions">
        <button type="button" className="btn btn-outline" onClick={onCancel} disabled={saving}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving..." : initialData ? "Update patient" : "Add patient"}
        </button>
      </div>
    </form>
  );
}

export default PatientForm;
