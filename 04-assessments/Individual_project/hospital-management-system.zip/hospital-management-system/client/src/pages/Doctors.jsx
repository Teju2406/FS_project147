import { useState, useEffect, useCallback } from "react";
import { FaPlus, FaEdit, FaTrashAlt, FaUserMd, FaPhone, FaEnvelope, FaClock } from "react-icons/fa";
import { api } from "../services/api.js";
import PageHeader from "../components/PageHeader.jsx";
import Modal from "../components/Modal.jsx";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import DoctorForm from "../components/DoctorForm.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Toast from "../components/Toast.jsx";

function Doctors() {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState(null);
  const [doctorToDelete, setDoctorToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [toast, setToast] = useState(null);

  const loadDoctors = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const data = await api.get("/doctors");
      setDoctors(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDoctors();
  }, [loadDoctors]);

  function openAddForm() {
    setEditingDoctor(null);
    setFormOpen(true);
  }

  function openEditForm(doctor) {
    setEditingDoctor(doctor);
    setFormOpen(true);
  }

  function closeForm() {
    setFormOpen(false);
    setEditingDoctor(null);
  }

  async function handleSave(values) {
    if (editingDoctor) {
      await api.put(`/doctors/${editingDoctor.id}`, values);
      setToast({ message: "Doctor updated successfully.", type: "success" });
    } else {
      await api.post("/doctors", values);
      setToast({ message: "Doctor added successfully.", type: "success" });
    }
    closeForm();
    loadDoctors();
  }

  async function handleDelete() {
    try {
      setDeleting(true);
      await api.delete(`/doctors/${doctorToDelete.id}`);
      setToast({ message: "Doctor deleted.", type: "success" });
      setDoctorToDelete(null);
      loadDoctors();
    } catch (err) {
      setToast({ message: err.message, type: "error" });
      setDoctorToDelete(null);
    } finally {
      setDeleting(false);
    }
  }

  function renderContent() {
    if (loading) return <Loader text="Loading doctors..." />;
    if (error) return <ErrorMessage message={error} onRetry={loadDoctors} />;
    if (doctors.length === 0) {
      return (
        <EmptyState
          icon={<FaUserMd />}
          title="No doctors yet"
          text='Click "Add Doctor" to add the first doctor.'
        />
      );
    }

    // Doctors are shown as cards
    return (
      <div className="doctor-grid">
        {doctors.map((d) => (
          <div className="doctor-card" key={d.id}>
            <div className="doctor-top">
              <div className="avatar">
                <FaUserMd />
              </div>
              <div>
                <h4>{d.name}</h4>
                <p className="muted">{d.specialization}</p>
              </div>
              <StatusBadge status={d.availability} />
            </div>

            <ul className="doctor-info">
              <li><FaClock /> {d.schedule}</li>
              <li><FaPhone /> {d.phone}</li>
              <li><FaEnvelope /> {d.email}</li>
            </ul>

            <div className="doctor-footer">
              <span className="muted">{d.id} &bull; {d.experience} yrs experience</span>
              <div className="row-actions">
                <button className="icon-btn edit" onClick={() => openEditForm(d)} title="Edit doctor" aria-label={`Edit ${d.name}`}>
                  <FaEdit />
                </button>
                <button className="icon-btn delete" onClick={() => setDoctorToDelete(d)} title="Delete doctor" aria-label={`Delete ${d.name}`}>
                  <FaTrashAlt />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Doctors" subtitle="Manage doctors, their specializations and availability.">
        <button className="btn btn-primary" onClick={openAddForm}>
          <FaPlus /> Add Doctor
        </button>
      </PageHeader>

      {renderContent()}

      {formOpen && (
        <Modal title={editingDoctor ? "Edit Doctor" : "Add New Doctor"} onClose={closeForm}>
          <DoctorForm initialData={editingDoctor} onSubmit={handleSave} onCancel={closeForm} />
        </Modal>
      )}

      {doctorToDelete && (
        <ConfirmDialog
          title="Delete doctor?"
          message={`Are you sure you want to delete ${doctorToDelete.name} (${doctorToDelete.id})? Their appointments will also be removed. This cannot be undone.`}
          confirmText="Yes, delete"
          loading={deleting}
          onConfirm={handleDelete}
          onCancel={() => setDoctorToDelete(null)}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

export default Doctors;
