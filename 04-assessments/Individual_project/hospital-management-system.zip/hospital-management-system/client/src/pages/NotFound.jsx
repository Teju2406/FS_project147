import { Link } from "react-router-dom";
import EmptyState from "../components/EmptyState.jsx";

// Shown when the URL does not match any page
function NotFound() {
  return (
    <div className="card">
      <EmptyState icon="404" title="Page not found" text="The page you are looking for does not exist." />
      <div className="center">
        <Link className="btn btn-primary" to="/">
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
}

export default NotFound;
