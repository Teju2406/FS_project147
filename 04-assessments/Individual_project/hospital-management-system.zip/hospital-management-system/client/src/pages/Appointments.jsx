import { useState, useEffect, useCallback } from "react";
import { FaPlus, FaEdit, FaBan, FaCheckCircle, FaCalendarCheck } from "react-icons/fa";
import { api } from "../services/api.js";
import { formatDate, formatTime } from "../utils/helpers.js";
import PageHeader from "../components/PageHeader.jsx";
import Modal from "../components/Modal.jsx";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import AppointmentForm from "../components/AppointmentForm.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Toast from "../components/Toast.jsx";

const FILTERS = ["All", "Scheduled", "Completed", "Cancelled"];

function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]); // needed for the booking form dropdown
  const [doctors, setDoctors] = useState([]); // needed for the booking form dropdown
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [formOpen, setFormOpen] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState(null);
  const [appointmentToCancel, setAppointmentToCancel] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  const [toast, setToast] = useState(null);

  // Load appointments, patients and doctors at the same time
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const [appointmentData, patientData, doctorData] = await Promise.all([
        api.get("/appointments"),
        api.get("/patients"),
        api.get("/doctors"),
      ]);
      setAppointments(appointmentData);
      setPatients(patientData);
      setDoctors(doctorData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const visibleAppointments = appointments
    .filter((a) => statusFilter === "All" || a.status === statusFilter)
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time)); // newest first

  function openBookForm() {
    setEditingAppointment(null);
    setFormOpen(true);
  }

  function openEditForm(appointment) {
    setEditingAppointment(appointment);
    setFormOpen(true);
  }

  function closeForm() {
    setFormOpen(false);
    setEditingAppointment(null);
  }

  async function handleSave(values) {
    if (editingAppointment) {
      await api.put(`/appointments/${editingAppointment.id}`, values);
      setToast({ message: "Appointment updated successfully.", type: "success" });
    } else {
      await api.post("/appointments", values);
      setToast({ message: "Appointment booked successfully.", type: "success" });
    }
    closeForm();
    loadData();
  }

  // "Complete" button: send the same appointment back with status = Completed
  async function handleComplete(appointment) {
    try {
      await api.put(`/appointments/${appointment.id}`, { ...appointment, status: "Completed" });
      setToast({ message: "Appointment marked as completed.", type: "success" });
      loadData();
    } catch (err) {
      setToast({ message: err.message, type: "error" });
    }
  }

  async function handleCancel() {
    try {
      setCancelling(true);
      await api.patch(`/appointments/${appointmentToCancel.id}/cancel`);
      setToast({ message: "Appointment cancelled.", type: "success" });
      setAppointmentToCancel(null);
      loadData();
    } catch (err) {
      setToast({ message: err.message, type: "error" });
      setAppointmentToCancel(null);
    } finally {
      setCancelling(false);
    }
  }

  function renderContent() {
    if (loading) return <Loader text="Loading appointments..." />;
    if (error) return <ErrorMessage message={error} onRetry={loadData} />;

    if (appointments.length === 0) {
      return (
        <EmptyState
          icon={<FaCalendarCheck />}
          title="No appointments yet"
          text='Click "Book Appointment" to schedule the first one.'
        />
      );
    }

    if (visibleAppointments.length === 0) {
      return (
        <EmptyState
          icon={<FaCalendarCheck />}
          title={`No ${statusFilter.toLowerCase()} appointments`}
          text="Try a different filter."
        />
      );
    }

    return (
      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Patient</th>
              <th>Doctor</th>
              <th>Date &amp; Time</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {visibleAppointments.map((a) => (
              <tr key={a.id}>
                <td data-label="ID">{a.id}</td>
                <td data-label="Patient"><strong>{a.patientName}</strong></td>
                <td data-label="Doctor">
                  {a.doctorName}
                  <br />
                  <small className="muted">{a.specialization}</small>
                </td>
                <td data-label="Date & Time">
                  {formatDate(a.date)}
                  <br />
                  <small className="muted">{formatTime(a.time)}</small>
                </td>
                <td data-label="Reason">{a.reason}</td>
                <td data-label="Status"><StatusBadge status={a.status} /></td>
                <td data-label="Actions">
                  <div className="row-actions">
                    <button className="icon-btn edit" onClick={() => openEditForm(a)} title="Edit appointment" aria-label={`Edit appointment ${a.id}`}>
                      <FaEdit />
                    </button>
                    {a.status === "Scheduled" && (
                      <>
                        <button className="icon-btn complete" onClick={() => handleComplete(a)} title="Mark as completed" aria-label={`Complete appointment ${a.id}`}>
                          <FaCheckCircle />
                        </button>
                        <button className="icon-btn delete" onClick={() => setAppointmentToCancel(a)} title="Cancel appointment" aria-label={`Cancel appointment ${a.id}`}>
                          <FaBan />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Appointments" subtitle="Book, update, complete or cancel appointments.">
        <button className="btn btn-primary" onClick={openBookForm}>
          <FaPlus /> Book Appointment
        </button>
      </PageHeader>

      <section className="card">
        <div className="toolbar">
          <div className="filter-tabs">
            {FILTERS.map((f) => (
              <button
                key={f}
                className={statusFilter === f ? "tab active" : "tab"}
                onClick={() => setStatusFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
          <span className="count-text">{visibleAppointments.length} appointments</span>
        </div>
        {renderContent()}
      </section>

      {formOpen && (
        <Modal title={editingAppointment ? "Update Appointment" : "Book New Appointment"} onClose={closeForm}>
          <AppointmentForm
            initialData={editingAppointment}
            patients={patients}
            doctors={doctors}
            onSubmit={handleSave}
            onCancel={closeForm}
          />
        </Modal>
      )}

      {appointmentToCancel && (
        <ConfirmDialog
          title="Cancel appointment?"
          message={`Cancel the appointment of ${appointmentToCancel.patientName} with ${appointmentToCancel.doctorName} on ${formatDate(appointmentToCancel.date)} at ${formatTime(appointmentToCancel.time)}?`}
          confirmText="Yes, cancel it"
          loading={cancelling}
          onConfirm={handleCancel}
          onCancel={() => setAppointmentToCancel(null)}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

export default Appointments;
