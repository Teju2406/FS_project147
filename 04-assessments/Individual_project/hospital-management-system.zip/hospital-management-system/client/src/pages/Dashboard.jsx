import { useState, useEffect } from "react";
import { FaUserInjured, FaUserMd, FaCalendarCheck, FaBed } from "react-icons/fa";
import { api } from "../services/api.js";
import { formatDate, formatTime } from "../utils/helpers.js";
import PageHeader from "../components/PageHeader.jsx";
import StatCard from "../components/StatCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import EmptyState from "../components/EmptyState.jsx";

// A simple horizontal bar made with CSS (no chart library needed).
// Props: label, value, total, color
function BarRow({ label, value, total, color }) {
  const percent = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div className="bar-row">
      <div className="bar-label">
        <span>{label}</span>
        <strong>{value}</strong>
      </div>
      <div className="bar-track">
        <div className={`bar-fill ${color}`} style={{ width: `${percent}%` }}></div>
      </div>
    </div>
  );
}

function Dashboard() {
  const [stats, setStats] = useState(null); // null until the data arrives
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadStats() {
    try {
      setLoading(true);
      setError("");
      const data = await api.get("/dashboard");
      setStats(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  // Runs once when the page first appears
  useEffect(() => {
    loadStats();
  }, []);

  if (loading) return <Loader text="Loading dashboard..." />;
  if (error) return <ErrorMessage message={error} onRetry={loadStats} />;

  const bedPercent = stats.totalBeds > 0 ? Math.round((stats.occupiedBeds / stats.totalBeds) * 100) : 0;

  return (
    <div>
      <PageHeader title="Dashboard" subtitle={`Welcome to ${stats.hospitalName} - here is today's overview.`} />

      {/* Four summary cards */}
      <div className="stats-grid">
        <StatCard title="Total Patients" value={stats.totalPatients} icon={<FaUserInjured />} color="blue" />
        <StatCard title="Total Doctors" value={stats.totalDoctors} icon={<FaUserMd />} color="green" />
        <StatCard title="Appointments" value={stats.totalAppointments} icon={<FaCalendarCheck />} color="teal" />
        <StatCard
          title="Available Beds"
          value={stats.availableBeds}
          icon={<FaBed />}
          color="orange"
          note={`out of ${stats.totalBeds} total`}
        />
      </div>

      <div className="dashboard-grid">
        {/* Recent appointments table */}
        <section className="card">
          <h3 className="card-title">Recent Appointments</h3>
          {stats.recentAppointments.length === 0 ? (
            <EmptyState icon={<FaCalendarCheck />} title="No appointments yet" text="Book an appointment to see it here." />
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Patient</th>
                    <th>Doctor</th>
                    <th>Date &amp; Time</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recentAppointments.map((a) => (
                    <tr key={a.id}>
                      <td>{a.patientName}</td>
                      <td>{a.doctorName}</td>
                      <td>
                        {formatDate(a.date)}, {formatTime(a.time)}
                      </td>
                      <td>
                        <StatusBadge status={a.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Statistics */}
        <section className="card">
          <h3 className="card-title">Bed Occupancy</h3>
          <BarRow label={`Occupied (${bedPercent}%)`} value={stats.occupiedBeds} total={stats.totalBeds} color="blue" />
          <BarRow label="Available" value={stats.availableBeds} total={stats.totalBeds} color="green" />

          <h3 className="card-title spaced">Appointments by Status</h3>
          <BarRow label="Scheduled" value={stats.appointmentsByStatus.Scheduled} total={stats.totalAppointments} color="blue" />
          <BarRow label="Completed" value={stats.appointmentsByStatus.Completed} total={stats.totalAppointments} color="green" />
          <BarRow label="Cancelled" value={stats.appointmentsByStatus.Cancelled} total={stats.totalAppointments} color="red" />
        </section>

        <section className="card">
          <h3 className="card-title">Patients by Status</h3>
          {Object.entries(stats.patientsByStatus).map(([status, count]) => (
            <BarRow key={status} label={status} value={count} total={stats.totalPatients} color="blue" />
          ))}
        </section>

        <section className="card">
          <h3 className="card-title">Doctor Availability</h3>
          {Object.entries(stats.doctorsByAvailability).map(([status, count]) => (
            <BarRow
              key={status}
              label={status}
              value={count}
              total={stats.totalDoctors}
              color={status === "Available" ? "green" : status === "On Leave" ? "orange" : "red"}
            />
          ))}
        </section>
      </div>
    </div>
  );
}

export default Dashboard;
