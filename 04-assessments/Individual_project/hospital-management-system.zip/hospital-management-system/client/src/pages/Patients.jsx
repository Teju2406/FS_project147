import { useState, useEffect, useCallback } from "react";
import { FaPlus, FaEdit, FaTrashAlt, FaSearch, FaUserInjured } from "react-icons/fa";
import { api } from "../services/api.js";
import PageHeader from "../components/PageHeader.jsx";
import Modal from "../components/Modal.jsx";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import PatientForm from "../components/PatientForm.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import EmptyState from "../components/EmptyState.jsx";
import Toast from "../components/Toast.jsx";

function Patients() {
  // ----- State -----
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false); // is the Add/Edit modal open?
  const [editingPatient, setEditingPatient] = useState(null); // null = adding a new patient
  const [patientToDelete, setPatientToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [toast, setToast] = useState(null); // { message, type }

  // ----- Load data from the backend -----
  const loadPatients = useCallback(async () => {
    try {
      setLoading(true);
      setError("");
      const data = await api.get("/patients");
      setPatients(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPatients();
  }, [loadPatients]);

  // ----- Search: match name or ID (case-insensitive) -----
  const searchText = search.trim().toLowerCase();
  const filteredPatients = patients.filter(
    (p) => p.name.toLowerCase().includes(searchText) || p.id.toLowerCase().includes(searchText)
  );

  // ----- Handlers -----
  function openAddForm() {
    setEditingPatient(null);
    setFormOpen(true);
  }

  function openEditForm(patient) {
    setEditingPatient(patient);
    setFormOpen(true);
  }

  function closeForm() {
    setFormOpen(false);
    setEditingPatient(null);
  }

  // Called by PatientForm. If it throws, the form shows the error.
  async function handleSave(values) {
    if (editingPatient) {
      await api.put(`/patients/${editingPatient.id}`, values);
      setToast({ message: "Patient updated successfully.", type: "success" });
    } else {
      await api.post("/patients", values);
      setToast({ message: "Patient added successfully.", type: "success" });
    }
    closeForm();
    loadPatients();
  }

  async function handleDelete() {
    try {
      setDeleting(true);
      await api.delete(`/patients/${patientToDelete.id}`);
      setToast({ message: "Patient deleted.", type: "success" });
      setPatientToDelete(null);
      loadPatients();
    } catch (err) {
      setToast({ message: err.message, type: "error" });
      setPatientToDelete(null);
    } finally {
      setDeleting(false);
    }
  }

  // ----- What to show -----
  function renderContent() {
    if (loading) return <Loader text="Loading patients..." />;
    if (error) return <ErrorMessage message={error} onRetry={loadPatients} />;

    if (patients.length === 0) {
      return (
        <EmptyState
          icon={<FaUserInjured />}
          title="No patients yet"
          text='Click "Add Patient" to register the first patient.'
        />
      );
    }

    if (filteredPatients.length === 0) {
      return (
        <EmptyState
          icon={<FaSearch />}
          title="No matching patients"
          text={`Nothing found for "${search}". Try a different name or ID.`}
        />
      );
    }

    return (
      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Age / Gender</th>
              <th>Phone</th>
              <th>Blood</th>
              <th>Condition</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPatients.map((p) => (
              <tr key={p.id}>
                <td data-label="ID">{p.id}</td>
                <td data-label="Name"><strong>{p.name}</strong></td>
                <td data-label="Age / Gender">{p.age} / {p.gender}</td>
                <td data-label="Phone">{p.phone}</td>
                <td data-label="Blood">{p.bloodGroup}</td>
                <td data-label="Condition">{p.condition}</td>
                <td data-label="Status"><StatusBadge status={p.status} /></td>
                <td data-label="Actions">
                  <div className="row-actions">
                    <button className="icon-btn edit" onClick={() => openEditForm(p)} title="Edit patient" aria-label={`Edit ${p.name}`}>
                      <FaEdit />
                    </button>
                    <button className="icon-btn delete" onClick={() => setPatientToDelete(p)} title="Delete patient" aria-label={`Delete ${p.name}`}>
                      <FaTrashAlt />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Patients" subtitle="Register, search, edit and remove patient records.">
        <button className="btn btn-primary" onClick={openAddForm}>
          <FaPlus /> Add Patient
        </button>
      </PageHeader>

      <section className="card">
        <div className="toolbar">
          <div className="search-box">
            <FaSearch />
            <input
              type="text"
              placeholder="Search by patient name or ID (e.g. P003)"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              aria-label="Search patients"
            />
          </div>
          <span className="count-text">
            {filteredPatients.length} of {patients.length} patients
          </span>
        </div>
        {renderContent()}
      </section>

      {formOpen && (
        <Modal title={editingPatient ? "Edit Patient" : "Add New Patient"} onClose={closeForm}>
          <PatientForm initialData={editingPatient} onSubmit={handleSave} onCancel={closeForm} />
        </Modal>
      )}

      {patientToDelete && (
        <ConfirmDialog
          title="Delete patient?"
          message={`Are you sure you want to delete ${patientToDelete.name} (${patientToDelete.id})? Their appointments will also be removed. This cannot be undone.`}
          confirmText="Yes, delete"
          loading={deleting}
          onConfirm={handleDelete}
          onCancel={() => setPatientToDelete(null)}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}

export default Patients;
