// server.js - entry point of the backend.
// Start it with:  npm start   (or  npm run dev  for auto-restart)

const express = require("express");
const cors = require("cors");

const patientRoutes = require("./routes/patients");
const doctorRoutes = require("./routes/doctors");
const appointmentRoutes = require("./routes/appointments");
const dashboardRoutes = require("./routes/dashboard");

const app = express();
const PORT = process.env.PORT || 5000;

// ---- Middleware ----
// CORS lets the React app (running on port 5173) call this server (port 5000).
app.use(
  cors({
    origin: ["http://localhost:5173", "http://127.0.0.1:5173"],
  })
);
// Lets us read JSON sent in request bodies as req.body
app.use(express.json());

// Simple request logger: prints e.g. "GET /api/patients"
app.use((req, res, next) => {
  console.log(`${req.method} ${req.originalUrl}`);
  next();
});

// ---- Routes ----
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Hospital Management API is running" });
});
app.use("/api/patients", patientRoutes);
app.use("/api/doctors", doctorRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/dashboard", dashboardRoutes);

// Unknown /api/... URL
app.use("/api", (req, res) => {
  res.status(404).json({ message: "API route not found." });
});

// ---- Error handler (runs when something throws) ----
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ message: "Invalid JSON in request body." });
  }
  console.error(err);
  res.status(500).json({ message: "Something went wrong on the server." });
});

// ---- Start the server ----
const server = app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

// Friendly message if the port is already in use
server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`Port ${PORT} is already in use. Close the other program or set a different port.`);
  } else {
    console.error(err);
  }
  process.exit(1);
});
