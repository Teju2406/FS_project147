// routes/doctors.js - REST API for doctors
//   GET    /api/doctors        -> list all
//   GET    /api/doctors/:id    -> one doctor
//   POST   /api/doctors        -> add a doctor
//   PUT    /api/doctors/:id    -> edit a doctor
//   DELETE /api/doctors/:id    -> delete a doctor (and their appointments)

const express = require("express");
const { readData, writeData, generateId } = require("../utils/db");
const { clean, validateDoctor } = require("../utils/validate");

const router = express.Router();
const FILE = "doctors.json";

function buildDoctor(body) {
  return {
    name: clean(body.name),
    specialization: clean(body.specialization),
    phone: clean(body.phone),
    email: clean(body.email),
    availability: body.availability,
    schedule: clean(body.schedule),
    experience: Number(body.experience),
  };
}

router.get("/", (req, res) => {
  res.json(readData(FILE));
});

router.get("/:id", (req, res) => {
  const doctor = readData(FILE).find((d) => d.id === req.params.id);
  if (!doctor) return res.status(404).json({ message: "Doctor not found." });
  res.json(doctor);
});

router.post("/", (req, res) => {
  const errors = validateDoctor(req.body);
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please fix the highlighted fields.", errors });
  }

  const doctors = readData(FILE);
  const newDoctor = { id: generateId(doctors, "D"), ...buildDoctor(req.body) };
  doctors.push(newDoctor);
  writeData(FILE, doctors);
  res.status(201).json(newDoctor);
});

router.put("/:id", (req, res) => {
  const doctors = readData(FILE);
  const index = doctors.findIndex((d) => d.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Doctor not found." });

  const errors = validateDoctor(req.body);
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please fix the highlighted fields.", errors });
  }

  doctors[index] = { ...doctors[index], ...buildDoctor(req.body) };
  writeData(FILE, doctors);
  res.json(doctors[index]);
});

router.delete("/:id", (req, res) => {
  const doctors = readData(FILE);
  const exists = doctors.some((d) => d.id === req.params.id);
  if (!exists) return res.status(404).json({ message: "Doctor not found." });

  writeData(FILE, doctors.filter((d) => d.id !== req.params.id));

  const appointments = readData("appointments.json");
  writeData("appointments.json", appointments.filter((a) => a.doctorId !== req.params.id));

  res.json({ message: "Doctor deleted successfully." });
});

module.exports = router;
