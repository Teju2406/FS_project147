// routes/appointments.js - REST API for appointments
//   GET    /api/appointments              -> list all (with patient & doctor names)
//   GET    /api/appointments/:id          -> one appointment
//   POST   /api/appointments              -> book an appointment
//   PUT    /api/appointments/:id          -> update an appointment
//   PATCH  /api/appointments/:id/cancel   -> cancel an appointment

const express = require("express");
const { readData, writeData, generateId } = require("../utils/db");
const { clean, todayString, validateAppointment } = require("../utils/validate");

const router = express.Router();
const FILE = "appointments.json";

// Add patientName, doctorName and specialization so the frontend can show them directly
function addNames(appointment, patients, doctors) {
  const patient = patients.find((p) => p.id === appointment.patientId);
  const doctor = doctors.find((d) => d.id === appointment.doctorId);
  return {
    ...appointment,
    patientName: patient ? patient.name : "Unknown patient",
    doctorName: doctor ? doctor.name : "Unknown doctor",
    specialization: doctor ? doctor.specialization : "",
  };
}

function buildAppointment(body) {
  return {
    patientId: clean(body.patientId),
    doctorId: clean(body.doctorId),
    date: clean(body.date),
    time: clean(body.time),
    reason: clean(body.reason),
    status: body.status || "Scheduled",
  };
}

// Extra rules that need data from other files. Returns an errors object.
// existing = the appointment being edited (undefined when booking a new one)
function checkBookingRules(data, existing) {
  const errors = {};
  const patients = readData("patients.json");
  const doctors = readData("doctors.json");
  const appointments = readData(FILE);

  if (!patients.some((p) => p.id === data.patientId)) {
    errors.patientId = "Selected patient does not exist.";
  }
  const doctor = doctors.find((d) => d.id === data.doctorId);
  if (!doctor) {
    errors.doctorId = "Selected doctor does not exist.";
  }

  // The rules below only matter for appointments that are still Scheduled
  if (data.status !== "Scheduled") return errors;

  const changedWhen =
    !existing ||
    existing.doctorId !== data.doctorId ||
    existing.date !== data.date ||
    existing.time !== data.time;

  if (changedWhen) {
    if (doctor && doctor.availability !== "Available") {
      errors.doctorId = `${doctor.name} is currently ${doctor.availability.toLowerCase()}.`;
    }
    if (data.date < todayString()) {
      errors.date = "Appointment date cannot be in the past.";
    }
  }

  // The same doctor cannot have two active appointments at the same date and time
  const clash = appointments.some(
    (a) =>
      a.doctorId === data.doctorId &&
      a.date === data.date &&
      a.time === data.time &&
      a.status === "Scheduled" &&
      (!existing || a.id !== existing.id)
  );
  if (clash) {
    errors.time = "This doctor already has an appointment at that date and time.";
  }

  return errors;
}

router.get("/", (req, res) => {
  const patients = readData("patients.json");
  const doctors = readData("doctors.json");
  const list = readData(FILE).map((a) => addNames(a, patients, doctors));
  res.json(list);
});

router.get("/:id", (req, res) => {
  const appointment = readData(FILE).find((a) => a.id === req.params.id);
  if (!appointment) return res.status(404).json({ message: "Appointment not found." });
  res.json(addNames(appointment, readData("patients.json"), readData("doctors.json")));
});

// Book a new appointment (status is always "Scheduled" when created)
router.post("/", (req, res) => {
  const body = { ...req.body, status: "Scheduled" };
  let errors = validateAppointment(body);
  if (Object.keys(errors).length === 0) {
    errors = checkBookingRules(buildAppointment(body));
  }
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please fix the highlighted fields.", errors });
  }

  const appointments = readData(FILE);
  const newAppointment = { id: generateId(appointments, "A"), ...buildAppointment(body) };
  appointments.push(newAppointment);
  writeData(FILE, appointments);
  res.status(201).json(
    addNames(newAppointment, readData("patients.json"), readData("doctors.json"))
  );
});

// Update an appointment (change doctor/date/time/reason or mark Completed/Cancelled)
router.put("/:id", (req, res) => {
  const appointments = readData(FILE);
  const index = appointments.findIndex((a) => a.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Appointment not found." });

  let errors = validateAppointment(req.body);
  if (Object.keys(errors).length === 0) {
    errors = checkBookingRules(buildAppointment(req.body), appointments[index]);
  }
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please fix the highlighted fields.", errors });
  }

  appointments[index] = { ...appointments[index], ...buildAppointment(req.body) };
  writeData(FILE, appointments);
  res.json(
    addNames(appointments[index], readData("patients.json"), readData("doctors.json"))
  );
});

// Cancel an appointment (we keep the record and just change its status)
router.patch("/:id/cancel", (req, res) => {
  const appointments = readData(FILE);
  const index = appointments.findIndex((a) => a.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Appointment not found." });

  if (appointments[index].status === "Completed") {
    return res.status(400).json({ message: "A completed appointment cannot be cancelled." });
  }
  if (appointments[index].status === "Cancelled") {
    return res.status(400).json({ message: "This appointment is already cancelled." });
  }

  appointments[index].status = "Cancelled";
  writeData(FILE, appointments);
  res.json(
    addNames(appointments[index], readData("patients.json"), readData("doctors.json"))
  );
});

module.exports = router;
