// routes/dashboard.js - GET /api/dashboard
// Reads all JSON files and calculates the numbers shown on the dashboard.

const express = require("express");
const { readData } = require("../utils/db");

const router = express.Router();

// Count how many items have each value of a field, e.g. { Male: 6, Female: 6 }
function countBy(list, field) {
  const counts = {};
  list.forEach((item) => {
    counts[item[field]] = (counts[item[field]] || 0) + 1;
  });
  return counts;
}

router.get("/", (req, res) => {
  const patients = readData("patients.json");
  const doctors = readData("doctors.json");
  const appointments = readData("appointments.json");
  const hospital = readData("hospital.json");

  // Each admitted patient occupies one bed
  const occupiedBeds = patients.filter((p) => p.status === "Admitted").length;
  const availableBeds = Math.max(hospital.totalBeds - occupiedBeds, 0);

  // Latest 5 appointments (newest date/time first), with names attached
  const recentAppointments = [...appointments]
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time))
    .slice(0, 5)
    .map((a) => {
      const patient = patients.find((p) => p.id === a.patientId);
      const doctor = doctors.find((d) => d.id === a.doctorId);
      return {
        ...a,
        patientName: patient ? patient.name : "Unknown patient",
        doctorName: doctor ? doctor.name : "Unknown doctor",
      };
    });

  res.json({
    hospitalName: hospital.name,
    totalPatients: patients.length,
    totalDoctors: doctors.length,
    totalAppointments: appointments.length,
    totalBeds: hospital.totalBeds,
    occupiedBeds,
    availableBeds,
    appointmentsByStatus: {
      Scheduled: appointments.filter((a) => a.status === "Scheduled").length,
      Completed: appointments.filter((a) => a.status === "Completed").length,
      Cancelled: appointments.filter((a) => a.status === "Cancelled").length,
    },
    patientsByStatus: countBy(patients, "status"),
    patientsByGender: countBy(patients, "gender"),
    doctorsByAvailability: countBy(doctors, "availability"),
    recentAppointments,
  });
});

module.exports = router;
