// routes/patients.js - REST API for patients
//   GET    /api/patients        -> list all (optional ?search=text)
//   GET    /api/patients/:id    -> one patient
//   POST   /api/patients        -> add a patient
//   PUT    /api/patients/:id    -> edit a patient
//   DELETE /api/patients/:id    -> delete a patient (and their appointments)

const express = require("express");
const { readData, writeData, generateId } = require("../utils/db");
const { clean, todayString, validatePatient } = require("../utils/validate");

const router = express.Router();
const FILE = "patients.json";

// Build a clean patient object from the request body (ignores unknown fields)
function buildPatient(body) {
  return {
    name: clean(body.name),
    age: Number(body.age),
    gender: body.gender,
    phone: clean(body.phone),
    email: clean(body.email) || "",
    address: clean(body.address) || "",
    bloodGroup: body.bloodGroup,
    condition: clean(body.condition),
    status: body.status,
  };
}

// GET all patients (with optional search by name or ID)
router.get("/", (req, res) => {
  let patients = readData(FILE);
  const search = (req.query.search || "").trim().toLowerCase();
  if (search) {
    patients = patients.filter(
      (p) =>
        p.name.toLowerCase().includes(search) ||
        p.id.toLowerCase().includes(search)
    );
  }
  res.json(patients);
});

// GET one patient
router.get("/:id", (req, res) => {
  const patient = readData(FILE).find((p) => p.id === req.params.id);
  if (!patient) return res.status(404).json({ message: "Patient not found." });
  res.json(patient);
});

// POST - add a new patient
router.post("/", (req, res) => {
  const errors = validatePatient(req.body);
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please fix the highlighted fields.", errors });
  }

  const patients = readData(FILE);
  const newPatient = {
    id: generateId(patients, "P"),
    ...buildPatient(req.body),
    registeredOn: todayString(),
  };
  patients.push(newPatient);
  writeData(FILE, patients);
  res.status(201).json(newPatient);
});

// PUT - edit an existing patient
router.put("/:id", (req, res) => {
  const patients = readData(FILE);
  const index = patients.findIndex((p) => p.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Patient not found." });

  const errors = validatePatient(req.body);
  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ message: "Please fix the highlighted fields.", errors });
  }

  // Keep id and registeredOn, replace the rest
  patients[index] = { ...patients[index], ...buildPatient(req.body) };
  writeData(FILE, patients);
  res.json(patients[index]);
});

// DELETE - remove a patient and any appointments that belong to them
router.delete("/:id", (req, res) => {
  const patients = readData(FILE);
  const exists = patients.some((p) => p.id === req.params.id);
  if (!exists) return res.status(404).json({ message: "Patient not found." });

  writeData(FILE, patients.filter((p) => p.id !== req.params.id));

  const appointments = readData("appointments.json");
  writeData("appointments.json", appointments.filter((a) => a.patientId !== req.params.id));

  res.json({ message: "Patient deleted successfully." });
});

module.exports = router;
