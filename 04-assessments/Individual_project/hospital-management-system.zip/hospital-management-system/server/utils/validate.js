// validate.js - reusable validation helpers used by the route files.
// Each validate function returns an "errors" object. Empty object = no errors.

const GENDERS = ["Male", "Female", "Other"];
const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const PATIENT_STATUSES = ["Outpatient", "Admitted", "Discharged"];
const DOCTOR_AVAILABILITY = ["Available", "Unavailable", "On Leave"];
const APPOINTMENT_STATUSES = ["Scheduled", "Completed", "Cancelled"];

const PHONE_REGEX = /^[0-9+\-\s]{7,15}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const TIME_REGEX = /^([01]\d|2[0-3]):[0-5]\d$/;

// Trim a value if it is a string, otherwise return it unchanged
function clean(value) {
  return typeof value === "string" ? value.trim() : value;
}

// Today's date as "YYYY-MM-DD" using the computer's local time
function todayString() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

// Check that "2026-10-18" is a real calendar date (rejects 2026-02-31 etc.)
function isRealDate(text) {
  if (!DATE_REGEX.test(text)) return false;
  const [year, month, day] = text.split("-").map(Number);
  const date = new Date(year, month - 1, day);
  return (
    date.getFullYear() === year &&
    date.getMonth() === month - 1 &&
    date.getDate() === day
  );
}

function validatePatient(body) {
  const errors = {};
  const name = clean(body.name);
  const age = Number(body.age);

  if (!name || name.length < 2) errors.name = "Name must be at least 2 characters.";
  if (body.age === "" || body.age === undefined || body.age === null || !Number.isInteger(age) || age < 0 || age > 120) {
    errors.age = "Age must be a whole number between 0 and 120.";
  }
  if (!GENDERS.includes(body.gender)) errors.gender = "Please select a gender.";
  if (!PHONE_REGEX.test(clean(body.phone) || "")) errors.phone = "Enter a valid phone number (7-15 digits).";
  if (clean(body.email) && !EMAIL_REGEX.test(clean(body.email))) errors.email = "Enter a valid email address.";
  if (!BLOOD_GROUPS.includes(body.bloodGroup)) errors.bloodGroup = "Please select a blood group.";
  if (!clean(body.condition)) errors.condition = "Condition / diagnosis is required.";
  if (!PATIENT_STATUSES.includes(body.status)) errors.status = "Please select a status.";
  return errors;
}

function validateDoctor(body) {
  const errors = {};
  const name = clean(body.name);
  const experience = Number(body.experience);

  if (!name || name.length < 2) errors.name = "Name must be at least 2 characters.";
  if (!clean(body.specialization)) errors.specialization = "Specialization is required.";
  if (!PHONE_REGEX.test(clean(body.phone) || "")) errors.phone = "Enter a valid phone number (7-15 digits).";
  if (!EMAIL_REGEX.test(clean(body.email) || "")) errors.email = "Enter a valid email address.";
  if (!DOCTOR_AVAILABILITY.includes(body.availability)) errors.availability = "Please select availability.";
  if (!clean(body.schedule)) errors.schedule = "Working schedule is required.";
  if (body.experience === "" || body.experience === undefined || body.experience === null || !Number.isInteger(experience) || experience < 0 || experience > 60) {
    errors.experience = "Experience must be a whole number between 0 and 60.";
  }
  return errors;
}

function validateAppointment(body) {
  const errors = {};
  if (!clean(body.patientId)) errors.patientId = "Please select a patient.";
  if (!clean(body.doctorId)) errors.doctorId = "Please select a doctor.";
  if (!isRealDate(clean(body.date) || "")) errors.date = "Please choose a valid date.";
  if (!TIME_REGEX.test(clean(body.time) || "")) errors.time = "Please choose a valid time.";
  if (!clean(body.reason) || clean(body.reason).length < 3) errors.reason = "Reason must be at least 3 characters.";
  if (!APPOINTMENT_STATUSES.includes(body.status)) errors.status = "Invalid status.";
  return errors;
}

module.exports = {
  clean,
  todayString,
  validatePatient,
  validateDoctor,
  validateAppointment,
};
