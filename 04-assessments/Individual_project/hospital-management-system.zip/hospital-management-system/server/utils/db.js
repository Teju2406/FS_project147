// db.js - tiny helper that reads and writes our JSON "database" files.
// Every route file uses these functions, so file handling lives in ONE place.

const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");

// Read a JSON file (e.g. "patients.json") and return it as a JavaScript object/array
function readData(fileName) {
  const filePath = path.join(DATA_DIR, fileName);
  const text = fs.readFileSync(filePath, "utf-8");
  return JSON.parse(text);
}

// Write a JavaScript object/array back to a JSON file (pretty-printed with 2 spaces)
function writeData(fileName, data) {
  const filePath = path.join(DATA_DIR, fileName);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
}

// Create the next unique ID, e.g. prefix "P" + existing max 12  ->  "P013"
function generateId(list, prefix) {
  let maxNumber = 0;
  list.forEach((item) => {
    const number = parseInt(String(item.id).slice(prefix.length), 10);
    if (!Number.isNaN(number) && number > maxNumber) {
      maxNumber = number;
    }
  });
  return prefix + String(maxNumber + 1).padStart(3, "0");
}

module.exports = { readData, writeData, generateId };
