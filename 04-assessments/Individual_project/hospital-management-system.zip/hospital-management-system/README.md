# Hospital Management System

A beginner-friendly **full stack web application** built for a third-year CSE (AI & ML) college project.

| Layer    | Technology                                   |
| -------- | -------------------------------------------- |
| Frontend | HTML5, CSS3, JavaScript, **React.js** (Vite) |
| Backend  | **Node.js + Express.js** (REST API)          |
| Database | **JSON files** (dummy data, no real database) |

All data is fictional. No paid service, no external API and no real patient information is used.

---

## 1. Features

- **Dashboard** – total patients, doctors, appointments, available beds, recent appointments, simple statistics.
- **Patients** – add, edit, delete (with confirmation), view in a table, search by name or ID.
- **Doctors** – add, edit, delete; shows specialization, availability and contact details.
- **Appointments** – book (patient + doctor + date + time), update, mark completed, cancel; status filter; blocks double-booking, past dates and unavailable doctors.
- **Responsive UI** – sidebar on desktop, slide-in menu on mobile, tables turn into cards on phones.
- Form validation (browser **and** server), loading states, empty states, error messages, success toasts.
- Every change is **saved to the JSON files by the backend**, so it survives a page refresh and a server restart.

---

## 2. Folder structure

```
hospital-management-system/
├── README.md
├── .gitignore
├── docs/
│   ├── PROJECT_REPORT.md          <- college report content
│   └── VIVA_AND_DEMO_GUIDE.md     <- viva Q&A, demo script, final checklist
├── server/                        <- BACKEND (Express.js)
│   ├── package.json
│   ├── server.js                  <- starts the server, CORS, routes, error handler
│   ├── routes/
│   │   ├── patients.js            <- /api/patients
│   │   ├── doctors.js             <- /api/doctors
│   │   ├── appointments.js        <- /api/appointments
│   │   └── dashboard.js           <- /api/dashboard
│   ├── utils/
│   │   ├── db.js                  <- read/write JSON files, generate IDs
│   │   └── validate.js            <- server-side validation
│   └── data/                      <- DUMMY DATABASE
│       ├── patients.json          <- 12 patients
│       ├── doctors.json           <- 6 doctors
│       ├── appointments.json      <- 12 appointments
│       └── hospital.json          <- hospital name + total beds
└── client/                        <- FRONTEND (React + Vite)
    ├── package.json
    ├── vite.config.js
    ├── index.html                 <- the single HTML page (HTML5)
    └── src/
        ├── main.jsx               <- starts React
        ├── App.jsx                <- layout + page routes
        ├── index.css              <- all styling (CSS3, responsive)
        ├── services/api.js        <- all fetch() calls in ONE place
        ├── utils/helpers.js       <- constants, date/time format, form validation
        ├── components/            <- reusable pieces
        │   ├── Sidebar.jsx  StatCard.jsx  PageHeader.jsx
        │   ├── Modal.jsx    ConfirmDialog.jsx  Toast.jsx
        │   ├── Loader.jsx   EmptyState.jsx  ErrorMessage.jsx  StatusBadge.jsx
        │   └── FormField.jsx  PatientForm.jsx  DoctorForm.jsx  AppointmentForm.jsx
        └── pages/
            ├── Dashboard.jsx  Patients.jsx  Doctors.jsx  Appointments.jsx  NotFound.jsx
```

### Architecture in one picture

```
  Browser (React app, port 5173)
        │   fetch("http://localhost:5000/api/patients")
        ▼
  Express server (port 5000)  ── validates ──►  routes/*.js
        │   readData() / writeData()
        ▼
  server/data/*.json   (the dummy database)
```

---

## 3. Setup on Windows (PowerShell)

### Step 1 – Install the required software

1. **Node.js (LTS version, 18 or newer)** – download from <https://nodejs.org> and run the installer (keep all defaults; it also installs `npm`).
   Or, in PowerShell: `winget install OpenJS.NodeJS.LTS`
2. **Visual Studio Code** (editor) – <https://code.visualstudio.com>
3. **Google Chrome or Edge** (browser).

**Close and re-open PowerShell** after installing Node.js.

### Step 2 – Check Node.js and npm

```powershell
node -v
npm -v
```

You should see version numbers (e.g. `v20.x.x` and `10.x.x`). If you see *"not recognized"*, restart PowerShell or your laptop, or reinstall Node.js.

> If PowerShell says *"running scripts is disabled on this system"* when you run `npm`, run this once and try again:
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
> ```

### Step 3 – Get the project folders

**Option A (easiest):** unzip `hospital-management-system.zip`, then open PowerShell inside it:

```powershell
cd C:\Users\YourName\Desktop\hospital-management-system
```

**Option B (create the folders yourself, then copy each file from this project):**

```powershell
cd $HOME\Desktop
mkdir hospital-management-system
cd hospital-management-system
mkdir docs, server, client
mkdir server\data, server\routes, server\utils
mkdir client\src, client\src\components, client\src\pages, client\src\services, client\src\utils
```

### Step 4 – Install dependencies (one time)

```powershell
cd server
npm install
cd ..\client
npm install
cd ..
```

Each `npm install` creates a `node_modules` folder. This needs internet and may take a minute or two.

### Step 5 – Start the backend (Terminal 1)

```powershell
cd server
npm start
```

You should see: `Server running at http://localhost:5000`
Quick check: open <http://localhost:5000/api/patients> in the browser – you should see JSON.
**Keep this window open.**

### Step 6 – Start the frontend (Terminal 2 – a NEW PowerShell window)

```powershell
cd hospital-management-system\client
npm run dev
```

You should see: `Local: http://localhost:5173/`

### Step 7 – Open the app

Go to **<http://localhost:5173>** in Chrome or Edge.

To stop either server press `Ctrl + C` in its terminal.

---

## 4. REST API reference

Base URL: `http://localhost:5000/api`

| Method | URL                          | What it does                          |
| ------ | ---------------------------- | ------------------------------------- |
| GET    | `/patients`                  | all patients (`?search=name-or-id`)   |
| GET    | `/patients/:id`              | one patient                           |
| POST   | `/patients`                  | add a patient                         |
| PUT    | `/patients/:id`              | edit a patient                        |
| DELETE | `/patients/:id`              | delete a patient (+ their appointments) |
| GET    | `/doctors`                   | all doctors                           |
| GET    | `/doctors/:id`               | one doctor                            |
| POST   | `/doctors`                   | add a doctor                          |
| PUT    | `/doctors/:id`               | edit a doctor                         |
| DELETE | `/doctors/:id`               | delete a doctor (+ their appointments) |
| GET    | `/appointments`              | all appointments (with names)         |
| GET    | `/appointments/:id`          | one appointment                       |
| POST   | `/appointments`              | book (status = Scheduled)             |
| PUT    | `/appointments/:id`          | update (reschedule / mark Completed)  |
| PATCH  | `/appointments/:id/cancel`   | cancel (status = Cancelled)           |
| GET    | `/dashboard`                 | dashboard statistics                  |
| GET    | `/health`                    | "is the server running?" check        |

Success codes: `200` OK, `201` created. Errors: `400` validation failed (body has `message` and `errors` per field), `404` not found, `500` server error.

---

## 5. Troubleshooting

| Problem | Fix |
| ------- | --- |
| `'node' is not recognized` | Install Node.js LTS, then close and reopen PowerShell. |
| `npm : File ... cannot be loaded because running scripts is disabled` | `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned` |
| `Cannot find module 'express'` / `'vite' is not recognized` | You skipped `npm install`. Run it inside the `server` and `client` folders. |
| `Port 5000 is already in use` (`EADDRINUSE`) | See "Free a port" below, or run `$env:PORT=5001; npm start` **and** set the same port in the client (see below). |
| Vite says port 5173 is in use | Free the port (below). It is fixed to 5173 because the backend's CORS setting allows that address. |
| Page loads but shows **"Cannot connect to the server..."** | Backend is not running. Start it in Terminal 1 and click **Try again**. |
| Browser console: **CORS error** | You opened the app on a different address/port. Use exactly `http://localhost:5173` (or `http://127.0.0.1:5173`). |
| Data looks empty or wrong after editing JSON by hand | Check the JSON is valid (no trailing commas). Restart the backend. |
| Changes in the code do not appear | Save the file; Vite reloads automatically. For backend changes press `Ctrl+C` and `npm start` again (or use `npm run dev`). |

**Free a port (example: 5000):**

```powershell
netstat -ano | findstr :5000
# the last number on the line is the PID, e.g. 12345
taskkill /PID 12345 /F
```

**Use a different backend port (example: 5001):**

```powershell
# Terminal 1
cd server
$env:PORT=5001
npm start

# Terminal 2
cd client
$env:VITE_API_URL="http://localhost:5001/api"
npm run dev
```

**Reset the sample data:** the JSON files in `server/data/` are the database. Your changes are written into them. If you want the original sample data back, re-copy the 3 files from the original zip.

---

## 6. Documentation

- `docs/PROJECT_REPORT.md` – abstract, problem statement, objectives, requirements, architecture, schema, test cases, conclusion.
- `docs/VIVA_AND_DEMO_GUIDE.md` – simple explanation, demo script, 30+ viva questions with answers, and the pre-demo checklist.

---

## 7. Notes

- The JSON files are a **learning-level database**. They are read and written on each request, which is fine for a demo but not for many users at once. See "Limitations" in the report.
- There is no login. A real hospital system must have authentication, encryption and privacy compliance.
